<?php

// Include your database connection
include 'db.php';

// Get the data from the AJAX request
$newProductData = $_POST;

// Perform validation if needed

// Escape the values to prevent SQL injection
$productName = mysqli_real_escape_string($conn, $newProductData['NewproductName']);
$doTest = mysqli_real_escape_string($conn, $newProductData['NewdoTest']);
$notes = mysqli_real_escape_string($conn, $newProductData['Newnotes']);

// Handle file upload
$newProductImage = isset($_FILES['newProductImage']) ? $_FILES['newProductImage'] : null;

// Check if a file was uploaded
if ($newProductImage && $newProductImage['error'] == 0) {
    $uploadsDirectory = 'img/'; // Update this with the path to your uploads directory

    // Get the file extension
    $fileExtension = pathinfo($newProductImage['name'], PATHINFO_EXTENSION);

    // Generate a random number for the file name
    $randomNumber = mt_rand(100000000, 999999999);

    // Construct the new file name with the random number and original extension
    $newFileName = $randomNumber . '.' . $fileExtension;

    // Combine the new file name with the uploads directory
    $uploadedFilePath = $uploadsDirectory . $newFileName;

    // Move the uploaded file to the destination directory
    if (move_uploaded_file($newProductImage['tmp_name'], $uploadedFilePath)) {
        // File upload successful, save the file path in the database
        $imagePath = mysqli_real_escape_string($conn, $uploadedFilePath);
    } else {
        // File upload failed
        $imagePath = 'img/default.jpg'; // Use the default image path

        // Add error handling and debugging statements
        $response = array('success' => false, 'message' => 'Error moving uploaded file: ' . $_FILES['newProductImage']['error']);
        header('Content-Type: application/json');
        echo json_encode($response);
        exit; // Stop further execution
    }
} else {
    // No file was uploaded
    $imagePath = 'img/default.jpg'; // Use the default image path
}


// Set default values for additional columns
$adlibraryInspirationVideos = '';
$competitorsLinks = '';
$alibabaAliexpressLinks = '';
$alibabaAliexpressPrice = '';
$myLpPpLink = '';
$myAdCopy = '';
$myVoiceOverScript = '';
$supplierName = '';
$sourcingPrice = 'N/A';
$productWeight = '';

// Construct your SQL query to insert the new product
$sql = "INSERT INTO product (ProductName, DoTest, Notes, ProductImage, AdlibraryInspirationVideos, CompetitorsLinks, AlibabaAliexpressLinks, AlibabaAliexpressPrice, MyLpPpLink, MyAdCopy, MyVoiceOverScript, SupplierName, SourcingPrice, ProductWeight)
        VALUES ('$productName', '$doTest', '$notes', '$imagePath', '$adlibraryInspirationVideos', '$competitorsLinks', '$alibabaAliexpressLinks', '$alibabaAliexpressPrice', '$myLpPpLink', '$myAdCopy', '$myVoiceOverScript', '$supplierName', '$sourcingPrice', '$productWeight')";

// Execute the query
if ($conn->query($sql) === TRUE) {
    $newProductId = $conn->insert_id; // Get the ID of the newly inserted product

    // Insert default values into countrystatus for the new product
    $defaultStatus = 'N/A';
    $defaultPrice = '';

    $countries = ['Ivory Coast', 'Senegal', 'Mali', 'Gabon', 'Guinea Conakry', 'Gambia', 'Cameroon', 'Argentina', 'RDC', 'Burkina Faso'];
    foreach ($countries as $country) {
        $countrySql = "INSERT INTO countrystatus (ProductID, Country, Status, VideosAdsStatus, VoiceOverStatus, ThumbnailsStatus, LpPpStatus, AdCopyStatus, ReviewsStatus, ProductPrice)
                       VALUES ('$newProductId', '$country', '$defaultStatus', '$defaultStatus', '$defaultStatus', '$defaultStatus', '$defaultStatus', '$defaultStatus', '$defaultStatus', '$defaultPrice')";
        $conn->query($countrySql);
    }

    $response = array('success' => true, 'message' => 'Product created successfully');
} else {
    $response = array('success' => false, 'message' => 'Error creating product: ' . $conn->error);
}

// Return the response as JSON
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn->close();
?>