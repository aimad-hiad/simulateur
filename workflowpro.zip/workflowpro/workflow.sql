-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 17 jan. 2024 à 22:20
-- Version du serveur :  10.4.14-MariaDB
-- Version de PHP : 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `workflow`
--

-- --------------------------------------------------------

--
-- Structure de la table `countrystatus`
--

CREATE TABLE `countrystatus` (
  `CountryStatusID` int(11) NOT NULL,
  `ProductID` int(11) DEFAULT NULL,
  `Country` varchar(255) NOT NULL,
  `Status` enum('WINNING','BURNED','TESTING','TEST AGAIN','TESTED','N/A') NOT NULL,
  `VideosAdsStatus` enum('N/A','IN PROGRESS','FINISHED') NOT NULL,
  `VoiceOverStatus` enum('N/A','IN PROGRESS','FINISHED') NOT NULL,
  `ThumbnailsStatus` enum('N/A','IN PROGRESS','FINISHED') NOT NULL,
  `LpPpStatus` enum('N/A','IN PROGRESS','FINISHED') NOT NULL,
  `AdCopyStatus` enum('N/A','IN PROGRESS','FINISHED') NOT NULL,
  `ReviewsStatus` enum('N/A','IN PROGRESS','FINISHED') NOT NULL,
  `ProductPrice` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `countrystatus`
--

INSERT INTO `countrystatus` (`CountryStatusID`, `ProductID`, `Country`, `Status`, `VideosAdsStatus`, `VoiceOverStatus`, `ThumbnailsStatus`, `LpPpStatus`, `AdCopyStatus`, `ReviewsStatus`, `ProductPrice`) VALUES
(1753, 1, 'Ivory Coast', 'WINNING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1754, 1, 'Senegal', 'WINNING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1755, 1, 'Mali', 'TESTING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1756, 1, 'Gabon', 'WINNING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1757, 1, 'Guinea Conakry', 'TESTED', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1758, 1, 'Gambia', 'TESTED', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1759, 1, 'Cameroon', 'WINNING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1760, 1, 'Argentina', 'TEST AGAIN', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1761, 1, 'RDC', 'TESTING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1762, 1, 'Burkina Faso', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1783, 2, 'Ivory Coast', 'TESTING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1784, 2, 'Senegal', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1785, 2, 'Mali', 'TESTING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1786, 2, 'Gabon', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1787, 2, 'Guinea Conakry', 'TESTED', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1788, 2, 'Gambia', 'TESTED', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1789, 2, 'Cameroon', 'WINNING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1790, 2, 'Argentina', 'TESTING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1791, 2, 'RDC', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1792, 2, 'Burkina Faso', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1823, 199, 'Ivory Coast', 'TESTING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1824, 199, 'Senegal', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1825, 199, 'Mali', 'TESTING', 'IN PROGRESS', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1826, 199, 'Gabon', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1827, 199, 'Guinea Conakry', 'TESTED', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1828, 199, 'Gambia', 'TESTED', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1829, 199, 'Cameroon', 'WINNING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1830, 199, 'Argentina', 'TESTING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1831, 199, 'RDC', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1832, 199, 'Burkina Faso', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1848, 201, 'Ivory Coast', 'WINNING', 'IN PROGRESS', 'IN PROGRESS', 'IN PROGRESS', 'N/A', 'N/A', 'N/A', '21000'),
(1849, 201, 'Senegal', 'N/A', 'IN PROGRESS', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1850, 201, 'Mali', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1851, 201, 'Gabon', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1852, 201, 'Guinea Conakry', 'WINNING', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1853, 201, 'Gambia', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1854, 201, 'Cameroon', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1855, 201, 'Argentina', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1856, 201, 'RDC', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(1857, 201, 'Burkina Faso', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A');

-- --------------------------------------------------------

--
-- Structure de la table `product`
--

CREATE TABLE `product` (
  `ProductID` int(11) NOT NULL,
  `ProductImage` varchar(255) DEFAULT NULL,
  `ProductName` varchar(255) NOT NULL,
  `DoTest` enum('YES','NO','N/A') NOT NULL,
  `Notes` text DEFAULT NULL,
  `AdlibraryInspirationVideos` text DEFAULT NULL,
  `CompetitorsLinks` text DEFAULT NULL,
  `AlibabaAliexpressLinks` text DEFAULT NULL,
  `AlibabaAliexpressPrice` varchar(255) DEFAULT NULL,
  `MyLpPpLink` varchar(255) DEFAULT NULL,
  `MyAdCopy` text DEFAULT NULL,
  `MyVoiceOverScript` text DEFAULT NULL,
  `SupplierName` varchar(255) DEFAULT NULL,
  `SourcingPrice` varchar(255) DEFAULT NULL,
  `ProductWeight` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `product`
--

INSERT INTO `product` (`ProductID`, `ProductImage`, `ProductName`, `DoTest`, `Notes`, `AdlibraryInspirationVideos`, `CompetitorsLinks`, `AlibabaAliexpressLinks`, `AlibabaAliexpressPrice`, `MyLpPpLink`, `MyAdCopy`, `MyVoiceOverScript`, `SupplierName`, `SourcingPrice`, `ProductWeight`) VALUES
(1, NULL, 'Product 1', 'YES', '', '', '', '', '', '', '', '', 'N/A', 'N/A', 'N/A'),
(2, NULL, 'Product 2', 'YES', '', '', '', '', '', '', '', '', 'N/A', 'N/A', 'N/A'),
(199, NULL, 'Product 3', 'YES', '', '', '', '', '', '', '', '', 'N/A', 'N/A', 'N/A'),
(201, NULL, 'igt', 'YES', '', '', '', '', '', '', '', '', 'N/A', 'N/A', 'N/A');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `countrystatus`
--
ALTER TABLE `countrystatus`
  ADD PRIMARY KEY (`CountryStatusID`),
  ADD KEY `ProductID` (`ProductID`),
  ADD KEY `idx_CountryStatus_Country` (`Country`);

--
-- Index pour la table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProductID`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `countrystatus`
--
ALTER TABLE `countrystatus`
  MODIFY `CountryStatusID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1858;

--
-- AUTO_INCREMENT pour la table `product`
--
ALTER TABLE `product`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `countrystatus`
--
ALTER TABLE `countrystatus`
  ADD CONSTRAINT `countrystatus_ibfk_1` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
