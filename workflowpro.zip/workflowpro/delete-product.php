<?php
// Include your database connection
include 'db.php';

// Get data from the POST request
$productIds = $_POST['productIds'];

// Start a transaction
$conn->begin_transaction();

// Loop through the product IDs and delete related country statuses first
foreach ($productIds as $productId) {
    $sqlDeleteCountryStatus = "DELETE FROM countrystatus WHERE ProductID = $productId";

    if ($conn->query($sqlDeleteCountryStatus) === FALSE) {
        // If there's an error in deleting country statuses, rollback the transaction
        $conn->rollback();
        $response = array('success' => false, 'message' => 'Error deleting country statuses: ' . $conn->error);
        echo json_encode($response);
        exit();
    }
}

// Now, delete the products
$sqlDeleteProducts = "DELETE FROM product WHERE ProductID IN (" . implode(',', $productIds) . ")";

if ($conn->query($sqlDeleteProducts) === TRUE) {
    // If the deletion is successful, commit the transaction
    $conn->commit();
    $response = array('success' => true, 'message' => 'Selected products deleted successfully');
} else {
    // If there's an error in deleting the products, rollback the transaction
    $conn->rollback();
    $response = array('success' => false, 'message' => 'Error deleting selected products: ' . $conn->error);
}

// Close the database connection
$conn->close();

// Set the content type to JSON
header('Content-Type: application/json');

// Echo the JSON-encoded response
echo json_encode($response);
?>
