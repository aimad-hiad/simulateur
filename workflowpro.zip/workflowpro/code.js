<script>
  // Declare productDetails as a global variable
  var productDetails;
 // Function to fetch product details by product ID
  function fetchProductDetails(productId) {
    $.ajax({
      type: 'GET',
      url: 'get_product_details.php',
      data: { productId: productId },
      dataType: 'json',
      success: function (response) {
        console.log('Product details for ID ' + productId + ':', response);
        // Populate the edit form with the fetched product details
        populateEditForm(response);
        // Assign the fetched product details to the global variable
        productDetails = response;
      },
      error: function (error) {
        console.error('Error fetching product details:', error);
        // Handle error (e.g., show an alert)
      }
    });
  }
 // Function to set default value for the "Work Progression" dropdown
  function setDefaultWorkProgression() {
    document.getElementById('FormCountryFilter').value = 'Ivory Coast';
  }
  // Function to handle the "Edit" button click
  function editProduct(productId) {
  // Check if Product Name is empty
    // Fetch product details before showing the modal
    fetchProductDetails(productId);
    // Show the edit product modal
    $('#editProductModal').modal('show');
	$('#productNameErrorEdit').text('Product Name is required!').hide();
    // Call the function to set the default value when the page loads
    setDefaultWorkProgression();
    // Call the function to update the form with product details
    updateEditForm();
    // Set the product ID for the "DELETE PRODUCT" button using the on method
    $('#deleteProductButton').off('click').on('click', function() {
        deleteProduct(productId);
    });
    // Reset the values of Videos Ads, Voice Over, Thumbnails, LP/PP, Adcopy, and Reviews dropdowns
    resetCreativeDropdowns();
  }
   // Function to update the "Edit Product" form with product details
  function updateEditForm() {
    // Check if productDetails is available
    if (productDetails) {
      // Populate the edit form with the fetched product details
      populateEditForm(productDetails);
    } else {
      // Handle the case when product details are not available
      console.error('Product details not available.');
      // You might want to display an error message or handle it differently
    }
  }
  // Function to populate the edit form with product details
  function populateEditForm(productDetails) {
    // Populate general product details
    $('#productName').val(productDetails.ProductName);
    $('#doTest').val(productDetails.DoTest);
  // Populate country-specific test results for each country
  populateCountryStatus(productDetails, 'Ivory Coast', 'statusIvoryCoast');
  populateCountryStatus(productDetails, 'Senegal', 'statusSenegal');
  populateCountryStatus(productDetails, 'Mali', 'statusMali');
  populateCountryStatus(productDetails, 'Gabon', 'statusGabon');
  populateCountryStatus(productDetails, 'Guinea Conakry', 'statusGuinea');
  populateCountryStatus(productDetails, 'Gambia', 'statusGambia');
  populateCountryStatus(productDetails, 'Cameroon', 'statusCameroon');
  populateCountryStatus(productDetails, 'Argentina', 'statusArgentina');
  populateCountryStatus(productDetails, 'RDC', 'statusRDC');
  populateCountryStatus(productDetails, 'Burkina Faso', 'statusBurkina');
    // Populate other form fields as needed
    $('input[name="productPrice"]').val(productDetails.ProductPrice);
    $('textarea[name="notes"]').val(productDetails.Notes);
	$('textarea[name="adlibrary"]').val(productDetails.AdlibraryInspirationVideos);
	$('textarea[name="competitorslp/pp"]').val(productDetails.CompetitorsLinks);
	$('textarea[name="alibaba/aliexpresslinks"]').val(productDetails.AlibabaAliexpressLinks);
	$('input[name="alibabaaliexpressprice"]').val(productDetails.AlibabaAliexpressPrice);
	$('textarea[name="mylp/pplink"]').val(productDetails.MyLpPpLink);
	$('textarea[name="myadcopy"]').val(productDetails.MyAdCopy);
	$('textarea[name="myvoiceoverscript"]').val(productDetails.MyVoiceOverScript);
    // Populate the "Sourcing" section as needed
    $('input[name="suppliername"]').val(productDetails.SupplierName);
    $('input[name="sourcingprice"]').val(productDetails.SourcingPrice);
    $('input[name="productweight"]').val(productDetails.ProductWeight);
  // Populate country-specific test results
  for (var i = 0; i < productDetails.CountryStatus.length; i++) {
    var countryStatus = productDetails.CountryStatus[i];
    // Correctly construct the name of the status dropdown based on the country name
    $('select[name="status' + countryStatus.Country.replace(/ /g, '') + '"]').val(countryStatus.Status);
  }
      // Prevent the default form submission
    event.preventDefault();
    // Get the selected country from the filter dropdown
    var selectedCountry = $('#FormCountryFilter').val();
    // Find the country in the product details
    var countryDetails = productDetails.CountryStatus.find(function (country) {
      return country.Country === selectedCountry;
    });
    // Update the "Product Price" field with the selected country's price
    if (countryDetails) {
      $('input[name="productPrice"]').val(countryDetails.ProductPrice);
      // Update the dropdowns with the selected country's status
      updateDropdown('videosAds', countryDetails.VideosAdsStatus);
      updateDropdown('voiceOver', countryDetails.VoiceOverStatus);
      updateDropdown('thumbnails', countryDetails.ThumbnailsStatus);
      updateDropdown('lppp', countryDetails.LpPpStatus);
      updateDropdown('adcopy', countryDetails.AdCopyStatus);
      updateDropdown('reviews', countryDetails.ReviewsStatus);
    } else {
      // If the selected country is not found, you may want to handle this case
      $('input[name="productPrice"]').val('');
      updateDropdown('videosAds', ''); // Set the dropdown to an empty value
      updateDropdown('voiceOver', ''); // Set the dropdown to an empty value
      updateDropdown('thumbnails', ''); // Set the dropdown to an empty value
      updateDropdown('lppp', ''); // Set the dropdown to an empty value
      updateDropdown('adcopy', ''); // Set the dropdown to an empty value
      updateDropdown('reviews', ''); // Set the dropdown to an empty value
    }
  }
// Function to populate the status dropdown for a specific country
function populateCountryStatus(productDetails, countryName, dropdownName) {
  // Find the country in the CountryStatus array
  const countryStatus = productDetails.CountryStatus.find(country => country.Country === countryName);
  // Set the status in the dropdown if found, otherwise set it to an empty string or a default value
  $(`select[name="${dropdownName}"]`).val(countryStatus ? countryStatus.Status : '');
}
  // Your existing code for fetching and updating products table
  function fetchProducts() {
    // Get filter values
    var countryFilter = document.getElementById('countryFilter').value;
    var doTestFilter = document.getElementById('doTestFilter').value;
    var statusFilter = document.getElementById('statusFilter').value;
    console.log('Filters:', countryFilter, doTestFilter, statusFilter);
    // Make an AJAX request to the server-side script
    $.ajax({
      type: 'GET',
      url: 'products.php',
      data: { country: countryFilter, doTest: doTestFilter, status: statusFilter },
      dataType: 'json',
      success: function (response) {
        console.log('Response from server:', response);
        // Update the products table with the fetched data
        updateProductsTable(response);
      },
      error: function (error) {
        console.error('Error fetching products:', error);
        // Display an error message in the table
        displayErrorMessage('Error fetching products');
      }
    });
  }
// Modify the fetchAllProducts function to accept parameters
function fetchAllProducts(countryFilter, doTestFilter, statusFilter) {
    // Log filter values (for debugging)
    console.log('Filters:', countryFilter, doTestFilter, statusFilter);

    // Make an AJAX request to the server-side script
    $.ajax({
        type: 'GET',
        url: 'products.php',
        data: { country: countryFilter, doTest: doTestFilter, status: statusFilter },
        dataType: 'json',
        success: function (response) {
            console.log('Response from server:', response);
            // Update the products table with the fetched data
            updateProductsTable(response);
        },
        error: function (error) {
            console.error('Error fetching products:', error);
            // Display an error message in the table
            displayErrorMessage('Error fetching products');
        }
    });
}
// Define a function to get the color based on the country status
function getCountryStatusColor(countryStatus) {
    switch (countryStatus) {
        case 'WINNING':
            return 'green'; // Set the color for 'WINNING'
        case 'BURNED':
            return 'red'; // Set the color for 'BURNED'
        case 'TESTING':
            return 'orange'; // Set the color for 'TESTING'
        case 'TESTED':
            return 'blue'; // Set the color for 'TESTED'
        case 'TEST AGAIN':
            return 'purple'; // Set the color for 'TEST AGAIN'
        case 'N/A':
            return 'gray'; // Set the color for 'N/A'
        default:
            return 'black'; // Default color if the country status doesn't match any case
    }
}
// Function to filter products based on the search input
function filterProducts() {
  var searchTerm = $('#searchProduct').val().toLowerCase();

  // Hide all product rows
  $('.product-row').hide();

  // Show only the product rows that match the search term
  $('.product-name').filter(function () {
    return $(this).text().toLowerCase().includes(searchTerm);
  }).closest('.product-row').show();
}
// Function to update the products table
function updateProductsTable(products) {
    var tableBody = document.getElementById('productsTableBody');
    tableBody.innerHTML = ''; // Clear existing rows

    // Check if products are not empty
    if (products.length > 0) {
        // Iterate through the products and create rows
        for (var i = 0; i < products.length; i++) {
            var product = products[i];

            // Combine status for all countries
            var combinedStatus = product.CountryStatus.map(function (countryStatus) {
                var flagFileName = 'flags/' + countryStatus.Country.toLowerCase() + '.PNG'; // Adjust the file extension if needed
                var flagStyle = 'width: 20px; height: auto;'; // Adjust the width to your preference

                var statusStyle;
                var statusText;

                switch (countryStatus.Status) {
                    case 'WINNING':
                        statusStyle = 'color: green; font-weight: bold;';
                        statusText = 'WINNING';
                        break;
                    case 'N/A':
                        statusStyle = 'color: black; font-weight: normal;';
                        statusText = 'N/A';
                        break;
                    case 'BURNED':
                        statusStyle = 'color: orange; font-weight: bold;';
                        statusText = 'BURNED';
                        break;
                    case 'TESTING':
                        statusStyle = 'color: blue; font-weight: bold;';
                        statusText = 'TESTING';
                        break;
                    case 'TESTED':
                        statusStyle = 'color: purple; font-weight: bold;';
                        statusText = 'TESTED';
                        break;
                    case 'TEST AGAIN':
                        statusStyle = 'color: brown; font-weight: bold;';
                        statusText = 'TEST AGAIN';
                        break;
                    default:
                        statusStyle = 'color: red; font-weight: normal;';
                        statusText = countryStatus.Status;
                }

                return '<div class="country-status">' +
                    '<img src="' + flagFileName + '" alt="Flag" class="country-flag" style="' + flagStyle + '">' +
                    ' ' + // Add a space here
                    countryStatus.Country + ': <span style="' + statusStyle + '">' + statusText + '</span>' +
                    '</div>';
            }).join('');

            // Create a row with checkbox, product name, and status in the same cell
            var row =
                '<tr class="product-row" data-product-id="' +
                product.ProductID +
                '">' +
                '<td class="product-name">' +
                '<input type="checkbox" class="product-checkbox" data-product-id="' +
                product.ProductID +
                '">&nbsp;&nbsp;' +
                product.ProductName +
                '</td>' +
                '<td>' +
                '<span class="do-test-symbol" style="color: ' + getColor(product.DoTest) + ';">' + getTestStatus(product.DoTest) + '</span>' +
                '</td>' +
                '<td style="text-align: left;">' +
                combinedStatus +
                '</td>' +
                '<td>' +
                product.SourcingPrice +
                '</td>' +
                '<td>' +
                '<button class="btn btn-info" onclick="editProduct(' +
                product.ProductID +
                ')">Edit</button> ' +
                '<button class="btn btn-danger" id="deleteProductButton" onclick="deleteProduct(' +
                product.ProductID +
                ')">Delete</button>' +
                '<button class="btn btn-success" id="duplicateProductButton" onclick="duplicateProduct(' +
                product.ProductID +
                ')">Duplicate</button>' +
                '</td>' +
                '</tr>';

            tableBody.innerHTML += row;
        }

        // Functions to determine color and status based on the value
        function getColor(doTest) {
            return doTest === 'YES' ? 'green' : (doTest === 'NO' ? 'red' : 'gray');
        }

        function getTestStatus(doTest) {
            return doTest === 'YES' ? '✔️ YES' : (doTest === 'NO' ? '❌ NO' : 'N/A');
        }
    } else {
        // If no products found, display a message in the table
        displayErrorMessage('No records found');
    }

    // Add "Select All" checkbox with arrow icons
    var selectAllCheckbox =
        '<div class="sticky-container">' +
        '<label>' +
        '<input type="checkbox" id="selectAllCheckbox">' +
        '<i class="unchecked-icon far fa-arrow-alt-circle-down"></i>' +
        '<i class="checked-icon fas fa-arrow-alt-circle-up"></i>' +
        'Select All' +
        '</label>' +
        '</div>';
    $('#productsTable').before(selectAllCheckbox);

    // Add event listener to "Select All" checkbox
    $('#selectAllCheckbox').on('change', function () {
        var isChecked = $(this).prop('checked');
        // Set all product checkboxes to the same state as "Select All"
        $('.product-checkbox').prop('checked', isChecked);

        // Update icon based on checkbox state
        updateSelectAllIcon(isChecked);
        updateCreateNewProductButtonState(); // Update button state
    });

    // Add event listener to rows for checkbox selection on row click
    $('.product-row').on('click', function (e) {
        // Exclude checkbox clicks
        if (e.target.type !== 'checkbox') {
            var productId = $(this).data('product-id');
            var checkbox = $(this).find('.product-checkbox');

            // Toggle the checkbox state
            checkbox.prop('checked', !checkbox.prop('checked'));

            // Update the "Select All" checkbox state based on the number of selected checkboxes
            updateSelectAllCheckboxState();
            updateCreateNewProductButtonState(); // Update button state
        }
    });
}
// Add event listener to the search input
$('#searchProduct').on('input', function () {
    filterProducts();
});
// Function to update the "Select All" checkbox state based on the number of selected checkboxes
function updateSelectAllCheckboxState() {
  var totalCheckboxes = $('.product-checkbox').length;
  var checkedCheckboxes = $('.product-checkbox:checked').length;
  $('#selectAllCheckbox').prop('checked', totalCheckboxes === checkedCheckboxes);
}
// Function to update the "CREATE NEW PRODUCT" button state based on the number of selected checkboxes
function updateCreateNewProductButtonState() {
  var selectedCheckboxes = $('.product-checkbox:checked').length;
  var deleteSelectedProductsButton = $('#deleteSelectedProductsButton');
  deleteSelectedProductsButton.prop('disabled', selectedCheckboxes === 0);
}
// Function to update the "Select All" checkbox icon based on its state
function updateSelectAllIcon(isChecked) {
  var icon = isChecked ? 'checked-icon' : 'unchecked-icon';
  $('#selectAllCheckbox').next('i').attr('class', 'far fa-arrow-alt-circle-down ' + icon);
}
// Function to update "Select All" icon based on checkbox state
function updateSelectAllIcon(isChecked) {
  var uncheckedIcon = isChecked ? 'far fa-arrow-alt-circle-up' : 'far fa-arrow-alt-circle-down';
  var checkedIcon = 'fas fa-arrow-alt-circle-up';
  $('.unchecked-icon').attr('class', uncheckedIcon);
  $('.checked-icon').attr('class', checkedIcon);
}
  // Function to display an error message in the table
  function displayErrorMessage(message) {
    var tableBody = document.getElementById('productsTableBody');
    tableBody.innerHTML = '<tr><td colspan="5">' + message + '</td></tr>';
  }

  // Function to apply filters and fetch products when the SEARCH button is clicked
  function applyFilters() {
    fetchProducts();
  }
  fetchProducts();
  // Function to apply filters and fetch products when the SEARCH ALL button is clicked
function applyAllFilters() {
    // Get filter values
    var countryFilter = 'ALL';
    var doTestFilter = 'ALL';
    var statusFilter = 'ALL';

    // Call fetchAllProducts with the specified filters
    fetchAllProducts(countryFilter, doTestFilter, statusFilter);
	// Set filter values to "ALL"
    document.getElementById('countryFilter').selectedIndex = 0; // Assuming "ALL" is the first option
    document.getElementById('doTestFilter').selectedIndex = 0;  // Assuming "ALL" is the first option
    document.getElementById('statusFilter').selectedIndex = 0;  // Assuming "ALL" is the first option
}
    fetchAllProducts();
   // Function to handle the "Filter" button click for Country
  function FilterCountry(event) {
    // Prevent the default form submission
    event.preventDefault();
    // Get the selected country from the filter dropdown
    var selectedCountry = $('#FormCountryFilter').val();
    // Find the country in the product details
    var countryDetails = productDetails.CountryStatus.find(function (country) {
      return country.Country === selectedCountry;
    });
    // Update the "Product Price" field with the selected country's price
    if (countryDetails) {
      $('input[name="productPrice"]').val(countryDetails.ProductPrice);
      // Update the dropdowns with the selected country's status
      updateDropdown('videosAds', countryDetails.VideosAdsStatus);
      updateDropdown('voiceOver', countryDetails.VoiceOverStatus);
      updateDropdown('thumbnails', countryDetails.ThumbnailsStatus);
      updateDropdown('lppp', countryDetails.LpPpStatus);
      updateDropdown('adcopy', countryDetails.AdCopyStatus);
      updateDropdown('reviews', countryDetails.ReviewsStatus);
    } else {
      // If the selected country is not found, you may want to handle this case
      $('input[name="productPrice"]').val('');
      updateDropdown('videosAds', ''); // Set the dropdown to an empty value
      updateDropdown('voiceOver', ''); // Set the dropdown to an empty value
      updateDropdown('thumbnails', ''); // Set the dropdown to an empty value
      updateDropdown('lppp', ''); // Set the dropdown to an empty value
      updateDropdown('adcopy', ''); // Set the dropdown to an empty value
      updateDropdown('reviews', ''); // Set the dropdown to an empty value
    }
  }
  // Function to update a dropdown with the specified value
  function updateDropdown(dropdownName, selectedValue) {
    // Get the dropdown element by name
    var dropdown = $('select[name="' + dropdownName + '"]');
    // Get the existing options in the dropdown
    var existingOptions = dropdown.children();
    // Clear the existing options
    dropdown.empty();
    // Define the possible status values
    var statusValues = ['N/A', 'IN PROGRESS', 'FINISHED'];
    // Iterate through the status values and add options to the dropdown
    for (var i = 0; i < statusValues.length; i++) {
      var statusValue = statusValues[i];
      var option = $('<option>', { value: statusValue, text: statusValue });
      // Append the option to the dropdown
      dropdown.append(option);
    }
    // Set the selected value in the dropdown
    dropdown.val(selectedValue);
  }
 // Function to reset the values of Videos Ads, Voice Over, Thumbnails, LP/PP, Adcopy, and Reviews dropdowns
function resetCreativeDropdowns() {
  $('select[name="videosAds"]').val('N/A');
  $('select[name="voiceOver"]').val('N/A');
  $('select[name="thumbnails"]').val('N/A');
  $('select[name="lppp"]').val('N/A');
  $('select[name="adcopy"]').val('N/A');
  $('select[name="reviews"]').val('N/A');
}
// Function to handle the "SAVE" button click
function saveProduct() {
  // Get the product ID
  var productId = productDetails.ProductID;
  // Get the updated values from the form
  var updatedProductName = $('#productName').val().trim(); // Trim leading and trailing whitespaces

  // Check if Product Name is empty
  if (!updatedProductName) {
    // Display an error message below the Product Name input
    $('#productNameErrorEdit').text('Product Name is required!').show();
    return; // Stop execution if there's an error
  }
  
  
  
  // Get the updated values from the form
  var updatedProductName = $('#productName').val();
  var updatedDoTest = $('#doTest').val();
  // Get the updated status for Ivory Coast
  var updatedStatusIvoryCoast = $('select[name="statusIvoryCoast"]').val();
  var updatedStatusSENEGAL = $('select[name="statusSenegal"]').val();
  var updatedStatusMALI = $('select[name="statusMali"]').val();
  var updatedStatusGUINEA = $('select[name="statusGuinea"]').val();
  var updatedStatusGAMBIA = $('select[name="statusGambia"]').val();
  var updatedStatusBURKINA = $('select[name="statusBurkina"]').val();
  var updatedStatusCAMEROON = $('select[name="statusCameroon"]').val();
  var updatedStatusARGENTINA = $('select[name="statusArgentina"]').val();
  var updatedStatusRDC = $('select[name="statusRDC"]').val();
  var updatedStatusGABON = $('select[name="statusGabon"]').val();
  
  var updatedNotes = $('textarea[name="notes"]').val();
  
 var updatedSupplierName = $('input[name="suppliername"]').val();
 var updatedSourcingPrice = $('input[name="sourcingprice"]').val();
 var updatedProductWeight = $('input[name="productweight"]').val();
 
 var updatedAdlibraryInspirationVideos = $('textarea[name="adlibrary"]').val();
 var updatedCompetitorsLPPLinks = $('textarea[name="competitorslp/pp"]').val();
 var updatedAlibabaAliexpressLinks = $('textarea[name="alibaba/aliexpresslinks"]').val(); // Added line for Alibaba/Aliexpress Links
 var updatedAlibabaAliexpressPrice = $('input[name="alibabaaliexpressprice"]').val(); // Added line for Alibaba/Aliexpress Price
 var updatedMyLpPpLink = $('textarea[name="mylp/pplink"]').val(); // Added line for My LP/PP Link
 var updatedMyAdCopy = $('textarea[name="myadcopy"]').val(); // Added line for My Ad Copy
 var updatedMyVoiceOverScript = $('textarea[name="myvoiceoverscript"]').val();
 
  // Get the value of the filter form for the country
 var selectedCountry = $('#FormCountryFilter').val();
 
var updatedVideosAds = $('select[name="videosAds"]').val();
var updatedVoiceOver = $('select[name="voiceOver"]').val();
var updatedThumbnails = $('select[name="thumbnails"]').val();
var updatedLppp = $('select[name="lppp"]').val();
var updatedAdcopy = $('select[name="adcopy"]').val();
var updatedReviews = $('select[name="reviews"]').val();
var updatedProductprice = $('input[name="productPrice"]').val();
 
  // Create an object with the updated data
 var updatedProductData = {
    productId: productId,
    productName: updatedProductName,
    doTest: updatedDoTest,
    statusIvoryCoast: updatedStatusIvoryCoast,
	statusSenegal: updatedStatusSENEGAL,
	statusMali: updatedStatusMALI,
	statusGuinea: updatedStatusGUINEA,
	statusGabon: updatedStatusGABON,
	statusGambia: updatedStatusGAMBIA,
	statusBurkina: updatedStatusBURKINA,
	statusCameroon: updatedStatusCAMEROON,
	statusRDC: updatedStatusRDC,
	statusArgentina: updatedStatusARGENTINA,
	
supplierName: updatedSupplierName,
sourcingPrice: updatedSourcingPrice,
productWeight: updatedProductWeight,

notes: updatedNotes,

adlibraryInspirationVideos: updatedAdlibraryInspirationVideos,
competitorsLPPLinks: updatedCompetitorsLPPLinks,
alibabaAliexpressLinks: updatedAlibabaAliexpressLinks, // Added line for Alibaba/Aliexpress Links
alibabaAliexpressPrice: updatedAlibabaAliexpressPrice, // Added line for Alibaba/Aliexpress Price
myLpPpLink: updatedMyLpPpLink, // Added line for My LP/PP Link
myAdCopy: updatedMyAdCopy, // Added line for My Ad Copy
myVoiceOverScript: updatedMyVoiceOverScript,

selectedCountry: selectedCountry,
videosAds: updatedVideosAds,
voiceOver: updatedVoiceOver,
thumbnails: updatedThumbnails,
lppp: updatedLppp,
adcopy: updatedAdcopy,
reviews: updatedReviews,
productPrice: updatedProductprice,

  };
  // Make an AJAX request to save the updated product data
  $.ajax({
    type: 'POST',
    url: 'save_product.php', // Replace with the actual server-side script
    data: updatedProductData,
    dataType: 'json',
    success: function (response) {
      console.log('Product updated successfully:', response);
      // Optionally, you can update the local productDetails variable with the updated data
      productDetails.ProductName = updatedProductName;
      productDetails.DoTest = updatedDoTest;
      // Update other fields in productDetails as needed
      // Optionally, you can also update the products table or perform any other actions
      fetchProducts(); // Fetch and update the products table
      // Hide the edit product modal
      $('#editProductModal').modal('hide');
    },
    error: function (error) {
      console.error('Error updating product:', error);
      // Handle the error (e.g., display an alert)
    }
  });
}
function deleteProduct(productId) {
    // Confirm the deletion with the user
    if (confirm("Are you sure you want to delete this product?")) {
    // Make an AJAX request to delete the product
    $.ajax({
        url: 'delete-product.php', // Replace with the correct path
        type: 'POST', // Change to 'POST' if your server expects POST requests
        data: { productIds: [productId] }, // Pass an array of product IDs
        success: function(response) {
            // Check if the deletion was successful
                if (response.success) {
                    console.log('Product deleted successfully:', response.message);
                    // Display a success message to the user
                    alert('Product deleted successfully');
                    // Optionally, you can update the products table or perform any other actions
                    fetchProducts(); // Fetch and update the products table

                    // If deleting from the edit form, hide the modal
                    $('#editProductModal').modal('hide');
                } else {
                    console.error('Error deleting product:', response.message);
                    // Handle the error (e.g., display an alert)
                }
            },
            error: function (error) {
                console.error('Error deleting product:', error);
                // Handle the error (e.g., display an alert)
            }
    });
    }
}
// Function to delete the selected products
function deleteSelectedProducts() {
  // Get the array of selected product IDs
  var selectedProductIds = $('.product-checkbox:checked').map(function () {
    return $(this).data('product-id');
  }).get();

  // Check if any products are selected
  if (selectedProductIds.length > 0) {
  
    // Confirm the deletion with the user
    if (confirm("Are you sure you want to delete the selected products?")) {
      // Make an AJAX request to delete the selected products using delete-product.php
	  $('#deleteSelectedProductsButton').prop('disabled', false);
      $.ajax({
        type: 'POST',
        url: 'delete-product.php', // Use the delete-product.php file
        data: { productIds: selectedProductIds },
        dataType: 'json',
        success: function (response) {
          if (response.success) {
            console.log('Selected products deleted successfully:', response.message);
            // Display a success message to the user
            alert('Selected products deleted successfully');
            // Optionally, you can update the products table or perform any other actions
            fetchProducts(); // Fetch and update the products table
          } else {
            console.error('Error deleting selected products:', response.message);
            // Handle the error (e.g., display an alert)
          }
        },
        error: function (error) {
          console.error('Error deleting selected products:', error);
          // Handle the error (e.g., display an alert)
        }
      });
    }
  } else {
    // If no products are selected, show a message
    //alert('No products selected for deletion.');
	//$('#deleteSelectedProductsButton').prop('disabled', true);
  }
}
// Function to handle the "DUPLICATE" button click
function duplicateProduct(productId) {
    // Confirm the duplication with the user
    if (confirm("Are you sure you want to duplicate this product?")) {
        // Make an AJAX request to duplicate the product
        $.ajax({
            type: 'POST',
            url: 'duplicate-product.php', // Replace with the actual server-side script
            data: { productId: productId },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    console.log('Product duplicated successfully:', response.message);
                    // Display a success message to the user
                    alert('Product duplicated successfully');
                    // Optionally, you can update the products table or perform any other actions
                    fetchProducts(); // Fetch and update the products table
                } else {
                    console.error('Error duplicating product:', response.message);
                    // Handle the error (e.g., display an alert)
                }
            },
            error: function (error) {
                console.error('Error duplicating product:', error);
                // Handle the error (e.g., display an alert)
            }
        });
    }
}
// Function to set default status for country filters
function setDefaultStatusForCountries() {
    $('select[name="FormCountryFilter"]').val('All');
}
// Function to set default status for a specific country in the form
function setDefaultStatusForCountry(countryName) {
    var dropdownName = 'status' + countryName.replace(/ /g, '');
    $('select[name="' + dropdownName + '"]').val('N/A');
}
// Function to set default status for creative elements
function setDefaultCreativeStatus() {
    $('select[name="videosAds"]').val('N/A');
    $('select[name="voiceOver"]').val('N/A');
    $('select[name="thumbnails"]').val('N/A');
    $('select[name="lppp"]').val('N/A');
    $('select[name="adcopy"]').val('N/A');
    $('select[name="reviews"]').val('N/A');
}
// Function to create a new product form
function createNewProductForm() {
    $('#createProductModal').modal('show');
    // Set default values for the form fields
    $('#NewproductName').val('Product for test');
    $('#NewdoTest').val('N/A'); // Set default value for Do-Test
    $('textarea[name="Newnotes"]').val('');
	$('#successMessage').text('Product created successfully!').hide();
	$('#productNameError').text('Product name is required!').hide();
    $('#saveProductButton')
        .css({
            'width': '100%', // Set the width to 100%
            'margin-top': '10px' // Add some top margin for spacing
        });
}
// Function to save a new product
function saveNewProduct() {
  // Get the value of the Product Name
  var newProductName = $('#NewproductName').val();

  // Check if the Product Name is not empty
  if (newProductName.trim() !== "") {
    // Clear any existing error message
    $('#productNameError').text('').hide();
	$('#productNameError1').text('Product name is required!').hide();
    // Get the values from the other form fields
    var newDoTest = $('#NewdoTest').val();
    var newNotes = $('textarea[name="Newnotes"]').val();

    // Create an object with the new product data
    var newProductData = {
      NewproductName: newProductName,
      NewdoTest: newDoTest,
      Newnotes: newNotes,
    };

    // Make an AJAX request to save the new product data
    $.ajax({
      type: 'POST',
      url: 'create_product.php',
      data: newProductData,
      dataType: 'json',
      success: function (response) {
        if (response.success) {
          console.log('Product Created successfully:', response.message);
          // Display a success message to the user
          $('#successMessage').text('Product created successfully!').show();
          // Fetch and update the products table
          fetchProducts();
          // If creating from the edit form, hide the modal
          //$('#createProductModal').modal('hide');
        } else {
          console.error('Error creating product:', response.message);
          // Handle the error (e.g., display an alert)
        }
      },
      error: function (error) {
        console.error('Error creating new product:', error);
        // Handle the error (e.g., display an alert)
      },
    });
  } else {
    // Display an error message below the Product Name input
    $('#productNameError').text('Product Name is required!').show();
  }
}

  function toggleSelectAll() {
    var selectAllCheckbox = document.getElementById("selectAllCheckbox");
    // You can add additional logic here if needed
  }
// Mapping of country names to flag file names
var countryFlagMap = {
    'Ivory Coast': 'flags/ivorycoast.PNG',
    'Mali': 'flags/mali.PNG',
    'Cameroon': 'flags/cameroon.PNG',
    'Gabon': 'flags/gabon.PNG',
    'Argentina': 'flags/argentina.PNG',
    'RDC': 'flags/rdc.PNG',
    'Senegal': 'flags/flags/senegal.PNG',
    'Guinea Conakry': 'flags/guineaconakry.PNG',
    'Gambia': 'flags/gambia.PNG',
	'Burkina Faso': 'flags/burkinafaso.PNG',
};

// Function to get the flag file name based on the country name
function getFlagFileName(countryName) {
    // Use the mapping to get the flag file name
    return countryFlagMap[countryName] || '';
}

// Function to set default flag for a specific country in the form
function setDefaultFlagForCountry(countryName) {
    var flagFileName = getFlagFileName(countryName);
    if (flagFileName) {
        $('#countryFlag').attr('src', flagFileName);
    }
}

// Handle country selection
function selectCountry(country) {
    updateButtonText(country);
    setDefaultFlagForCountry(country);
}

// Update button text with the selected country and flag
function updateButtonText(country) {
    var flagFileName = getFlagFileName(country);
    document.getElementById('countryButtonText').innerText = country;
    $('#countryFlag').attr('src', flagFileName);
}

// Set Ivory Coast as default
$(document).ready(function() {
    selectCountry('Ivory Coast');
});
// Get the input fields and button
  var productNameInput = document.getElementById('NewproductName');
  var doTestSelect = document.getElementById('NewdoTest');
  var notesTextarea = document.getElementsByName('Newnotes')[0];
  var createButton = document.getElementById('saveProductButton'); // Adjust the ID based on your actual button ID

  // Add an event listener for the keypress event on the input fields
  productNameInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      // Prevent the default behavior of the Enter key
      e.preventDefault();

      // Trigger the click event on the create button
      createButton.click();
    }
  });

  doTestSelect.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      // Prevent the default behavior of the Enter key
      e.preventDefault();

      // Trigger the click event on the create button
      createButton.click();
    }
  });

  notesTextarea.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      // Prevent the default behavior of the Enter key
      e.preventDefault();

      // Trigger the click event on the create button
      createButton.click();
    }
  });
</script>