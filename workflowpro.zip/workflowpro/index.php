<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="fav.png" type="image/x-icon">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
  integrity="sha384-xrRvAImOu7QpJzSpNfgZc40zxmIbN7fPQkIk5Ixwr2Xk5PAMTgAz2LHf4hB+qQ1Q"
  crossorigin="anonymous"/>
  <link rel="stylesheet" href="style.css"/>
  <title>WorkFlowPro | SIMPLIFY - ORGANIZE - ACHIEVE</title>
</head>
<body style="background-color: #F8F8F8;">
<div class="header">
    <div class="logo">
        <img src="workflowprologo.png" alt="Shipsen simulator">
    </div>
</div>
  <div class="container-fluid mt-5">
  <div class="content">
        <h1 style="text-align: left; margin-top: 120px;">
            Empower Your <span style="color: #4285f4;">E-commerce</span> Journey with WorkflowPro: Where Tasks Meet Simplicity for You!
        </h1>
        <p style="text-align: left; color: gray; margin-top: 15px;">
            WorkflowPro is here to redefine how you manage your e-commerce tasks. With its advanced features and real-time efficiency, it empowers you to optimize your workflow, streamline processes, and maximize productivity. Take charge of your e-commerce journey and unlock your organizational potential with WorkflowPro today!
        </p>
        <p style="text-align: left; color: gray; margin-top: 10px;">Now available for Cash on Delivery (COD) operations in the following countries:</p>
        <table style="border-collapse: collapse; margin-left: 0;">
            <tr>
                <td style="padding-right: 10px;"><img src="flags/ivorycoast.png" alt="Côte d'Ivoire Flag" style="width: 20px; height: 15px;"></td>
                <td style="padding-right: 30px;"><strong style="color: gray; font-weight: 600;">Côte d'Ivoire</strong></td>
                <td style="padding-right: 10px;"><img src="flags/burkinafaso.png" alt="Burkina Faso Flag" style="width: 20px; height: 15px;"></td>
                <td style="padding-right: 30px;"><strong style="color: gray; font-weight: 600;">Burkina Faso</strong></td>
				<td><img src="flags/senegal.png" alt="Senegal Flag" style="width: 20px; height: 15px;"></td>
                <td style="padding-right: 60px;"><strong style="color: gray; font-weight: 600;">Senegal</strong></td>
                <td><img src="flags/rdc.png" alt="Congo Kinshasa Flag" style="width: 20px; height: 15px;"></td>
                <td><strong style="color: gray; font-weight: 600;">Congo Kinshasa</strong></td>
                <td><img src="flags/cameroon.png" alt="Cameroon" style="width: 20px; height: 15px;"></td>
                <td><strong style="color: gray; font-weight: 600;">Cameroon</strong></td>
            </tr>
            <tr>
                <td><img src="flags/gabon.png" alt="Gabon Flag" style="width: 20px; height: 15px;"></td>
                <td style="padding-right: 80px;"><strong style="color: gray; font-weight: 600;">Gabon</strong></td>
                <td><img src="flags/gambia.png" alt="Gambia Flag" style="width: 20px; height: 15px;"></td>
                <td><strong style="color: gray; font-weight: 600;">Gambia</strong></td>
                <td><img src="flags/mali.png" alt="Mali Flag" style="width: 20px; height: 15px;"></td>
                <td style="padding-right: 30px;"><strong style="color: gray; font-weight: 600;">Mali</strong></td>
				<td><img src="flags/guineaconakry.png" alt="Guinea Conakry Flag" style="width: 20px; height: 15px;"></td>
                <td style="padding-right: 30px;"><strong style="color: gray; font-weight: 600;">Guinea Conakry</strong></td>
            </tr>
        </table>
</div>
    <!-- Ultimate Sticky Container -->
    <div class="ultimate-sticky-container">

      <!-- Ultimate Filter Container -->
      <div class="ultimate-filter-container">
        <!-- First Filter Dropdowns -->
        <div class="ultimate-col">
          <label for="countryFilter">Country:</label>
          <select id="countryFilter" class="ultimate-form-control">
		  <option value="ALL">ALL</option>
          <option value="Ivory Coast">Ivory Coast</option>
          <option value="Senegal">Senegal</option>
          <option value="Mali">Mali</option>
          <option value="Gabon">Gabon</option>
          <option value="Guinea Conakry">Guinea Conakry</option>
          <option value="Gambia">Gambia</option>
          <option value="Cameroon">Cameroon</option>
          <option value="Argentina">Argentina</option>
          <option value="RDC">RDC</option>
		  <option value="burkina">Burkina Faso</option>
          </select>
        </div>
        <div class="ultimate-col">
          <label for="doTestFilter">Do-Test:</label>
          <select id="doTestFilter" class="ultimate-form-control">
            <option value="ALL">ALL</option>
            <option value="YES">YES</option>
            <option value="NO">NO</option>
          </select>
        </div>
        <div class="ultimate-col">
          <label for="statusFilter">Status:</label>
          <select id="statusFilter" class="ultimate-form-control">
			<option value="ALL">ALL</option>
            <option value="WINNING">WINNING</option>
            <option value="BURNED">BURNED</option>
            <option value="TESTING">TESTING</option>
            <option value="TEST AGAIN">TEST AGAIN</option>
            <option value="TESTED">TESTED</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
        <!-- Search Button -->
        <div class="ultimate-mt-4">
          <button class="ultimate-btn ultimate-btn-primary" onclick="applyFilters()">SEARCH</button>
        </div>
        <div class="ultimate-mt-4">
          <!-- Show All Button -->
          <button class="ultimate-btn ultimate-btn-secondary" onclick="applyAllFilters()">SHOW ALL PRODUCTS</button>
        </div>
      </div>
      <!-- Create New Product Button -->
      <div class="ultimate-create-product-button">
        <!-- Add the search box here -->
        <div class="ultimate-search-box">
          <input type="text" id="searchProduct" placeholder="Search for products...">
        </div>
        <div class="ultimate-select-all-delete">
        <button type="button" class="ultimate-btn ultimate-btn-success" onclick="createNewProductForm()">+ CREATE NEW PRODUCT
        </button>
		          <label class="ultimate-select-all-label">
            <input type="checkbox" id="selectAllCheckbox" onchange="toggleSelectAll()">
            <i class="ultimate-unchecked-icon far fa-arrow-alt-circle-down"></i>
            <i class="ultimate-checked-icon fas fa-arrow-alt-circle-up"></i>
            Select All
          </label>
		  <button type="button" class="ultimate-btn ultimate-btn-danger" onclick="deleteSelectedProducts()" id="deleteSelectedProductsButton" disabled>DELETE SELECTED PRODUCTS</button>
		</div>
      </div>
    </div>

    <!-- Products Table Section -->
    <div class="product-table-container">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Do-Test</th>
              <th>Status</th>
              <th>Sourcing Price</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="productsTableBody">
            <!-- Product rows will be dynamically added here -->
          </tbody>
        </table>
    </div>
<!-- Create Product Modal -->
<div class="modal" id="createProductModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Create New Product</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!-- Modal Body -->
      <div class="modal-body">
        <br>
        <h5><center>Product Details</center></h5>
        <form id="productDetailsForm">
          <!-- Image upload field -->
          <div class="form-group">
            <label for="productImage">Product Image:</label>
            <input type="file" class="form-control" id="newProductImage" onchange="displayImagePreview()">
            <div id="productImageError" class="alert alert-danger" style="display: none;">Product image is required!</div>
          </div>
		<!-- Display uploaded image -->
		<div id="imagePreviewContainer" class="text-center" style="display: none;">
		  <img id="imagePreview" alt="Product Image" style="max-width: 300px; height: auto; border-radius: 10px;" class="img-fluid">
		</div>
          <div class="form-group">
            <label for="productName">Product Name: <i class="fas fa-pencil-alt edit-icon"></i></label>
            <input type="text" class="form-control" id="NewproductName" name="productName">
            <div id="productNameError" class="alert alert-danger" style="display: none;">Product name is required!</div>
          </div>
          <div class="form-group">
            <label for="doTest">Do-Test: <i class="fas fa-pencil-alt edit-icon"></i></label>
            <select class="form-control" id="NewdoTest" name="doTest">
              <option value="N/A">N/A</option>
              <option value="YES">YES</option>
              <option value="NO">NO</option>
            </select>
          </div>
          <div class="form-group">
            <label>Notes: <i class="fas fa-pencil-alt edit-icon"></i></label>
            <textarea class="form-control" name="Newnotes" rows="3" placeholder="Enter Notes"></textarea>
          </div>
          <div class="alert alert-success" role="alert" id="errorMessage" style="display: none;">
            New product created successfully!
          </div>
        </form>
      </div>
      <!-- Modal Footer -->
      <div class="modal-footer justify-content-center">
        <button type="button" id="saveProductButton" class="btn btn-primary" onclick="saveNewProduct()">Create</button>
      </div>
      <!-- Success Message -->
      <div class="alert alert-success" role="alert" id="successMessage" style="display: none;">
        New product created successfully!
      </div>
    </div>
  </div>
</div>
<!-- Edit Product Modal -->
  <div class="modal" id="editProductModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Edit Product</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal Body -->
        <div class="modal-body">
<!-- Stylish Tabs -->
<ul class="nav nav-tabs stylish-tabs" id="editProductTabs" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="generalInfoTab" data-toggle="tab" href="#generalInfo" role="tab">General Info</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="testResultsTab" data-toggle="tab" href="#testResults" role="tab">Test Results</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="workProgressionTab" data-toggle="tab" href="#workProgression" role="tab">Work Progression</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="creativesTab" data-toggle="tab" href="#creatives" role="tab">Creatives</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="sourcingTab" data-toggle="tab" href="#sourcing" role="tab">Sourcing</a>
  </li>
  <!-- Add more tabs as needed -->
</ul>

          <div class="tab-content mt-3">
            <!-- General Info Tab -->
            <div class="tab-pane show active" id="generalInfo" role="tabpanel">
              <form id="productDetailsForm">
		<!-- Display the product image -->
			<div class="form-group">
				<div id="productImageContainer" style="max-width: 100%; text-align: center;">
					<img id="productImagePreview" src="" alt="Product Image" style="max-width: 350px; object-fit: cover; cursor: pointer;">
					<input type="file" id="productImageInput" style="display: none;" accept="image/*">
				</div>
			</div>
          <div class="form-group">
            <label for="productName">Product Name:</label>
            <input type="text" class="form-control" id="productName" name="productName">
			<div id="productNameErrorEdit" class="alert alert-danger" style="display: none;">Product name is required!</div>
          </div>
          <div class="form-group">
            <label for="doTest">Do-Test:</label>
            <select class="form-control" id="doTest" name="doTest">
			  <option value="N/A">N/A</option>
              <option value="YES">YES</option>
              <option value="NO">NO</option>
            </select>
          </div>
		<div class="form-group">
			<label>Notes:</label>
			<textarea class="form-control" name="notes" rows="3" placeholder="Enter Notes"></textarea>
		</div>
              </form>
            </div>
<!-- Test Results of each country -->
<div class="tab-pane" id="testResults" role="tabpanel">
  <form id="testResultsForm">
    <div class="form-group">
      <!-- Ivory Coast and Senegal -->
      <div class="row mb-3">
        <div class="col-md-1">
          <img src="flags/ivorycoast.png" alt="Ivory Coast Flag" class="country-flag">
        </div>
        <div class="col-md-5">
          <label for="statusIvoryCoast">Ivory Coast:</label>
          <select class="form-control" name="statusIvoryCoast">
            <option value="WINNING">WINNING</option>
            <option value="BURNED">BURNED</option>
            <option value="TESTING">TESTING</option>
            <option value="TEST AGAIN">TEST AGAIN</option>
            <option value="TESTED">TESTED</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
        <div class="col-md-1">
          <img src="flags/senegal.png" alt="Senegal Flag" class="country-flag">
        </div>
        <div class="col-md-5">
          <label for="senegal">Senegal:</label>
          <select class="form-control" name="statusSenegal">
            <option value="WINNING">WINNING</option>
            <option value="BURNED">BURNED</option>
            <option value="TESTING">TESTING</option>
            <option value="TEST AGAIN">TEST AGAIN</option>
            <option value="TESTED">TESTED</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
      </div>

      <!-- Guinea Conakry and Gambia -->
      <div class="row mb-3">
        <div class="col-md-1">
          <img src="flags/guineaconakry.png" alt="Guinea Conakry Flag" class="country-flag">
        </div>
        <div class="col-md-5">
          <label for="guinea">Guinea Conakry:</label>
          <select class="form-control" name="statusGuinea">
            <option value="WINNING">WINNING</option>
            <option value="BURNED">BURNED</option>
            <option value="TESTING">TESTING</option>
            <option value="TEST AGAIN">TEST AGAIN</option>
            <option value="TESTED">TESTED</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
        <div class="col-md-1">
          <img src="flags/gambia.png" alt="Gambia Flag" class="country-flag">
        </div>
        <div class="col-md-5">
          <label for="gambia">Gambia:</label>
          <select class="form-control" name="statusGambia">
            <option value="WINNING">WINNING</option>
            <option value="BURNED">BURNED</option>
            <option value="TESTING">TESTING</option>
            <option value="TEST AGAIN">TEST AGAIN</option>
            <option value="TESTED">TESTED</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
      </div>

      <!-- gabon and mali -->
      <div class="row mb-3">
        <div class="col-md-1">
          <img src="flags/mali.png" alt="Mali Flag" class="country-flag">
        </div>
        <div class="col-md-5">
          <label for="mali">Mali:</label>
          <select class="form-control" name="statusMali">
            <option value="WINNING">WINNING</option>
            <option value="BURNED">BURNED</option>
            <option value="TESTING">TESTING</option>
            <option value="TEST AGAIN">TEST AGAIN</option>
            <option value="TESTED">TESTED</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
        <div class="col-md-1">
          <img src="flags/gabon.png" alt="Gabon Flag" class="country-flag">
        </div>
        <div class="col-md-5">
          <label for="gabon">Gabon:</label>
          <select class="form-control" name="statusGabon">
            <option value="WINNING">WINNING</option>
            <option value="BURNED">BURNED</option>
            <option value="TESTING">TESTING</option>
            <option value="TEST AGAIN">TEST AGAIN</option>
            <option value="TESTED">TESTED</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
      </div>

      <!-- cameroon and argentina -->
      <div class="row mb-3">
        <div class="col-md-1">
          <img src="flags/cameroon.png" alt="Cameroon Flag" class="country-flag">
        </div>
        <div class="col-md-5">
          <label for="cameroon">Cameroon:</label>
          <select class="form-control" name="statusCameroon">
            <option value="WINNING">WINNING</option>
            <option value="BURNED">BURNED</option>
            <option value="TESTING">TESTING</option>
            <option value="TEST AGAIN">TEST AGAIN</option>
            <option value="TESTED">TESTED</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
        <div class="col-md-1">
          <img src="flags/argentina.png" alt="Argentina Flag" class="country-flag">
        </div>
        <div class="col-md-5">
          <label for="argentina">Argentina:</label>
          <select class="form-control" name="statusArgentina">
            <option value="WINNING">WINNING</option>
            <option value="BURNED">BURNED</option>
            <option value="TESTING">TESTING</option>
            <option value="TEST AGAIN">TEST AGAIN</option>
            <option value="TESTED">TESTED</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
      </div>

      <!-- rdc and burkina faso -->
      <div class="row mb-3">
        <div class="col-md-1">
          <img src="flags/rdc.png" alt="RDC Flag" class="country-flag">
        </div>
        <div class="col-md-5">
          <label for="rdc">RDC:</label>
          <select class="form-control" name="statusRDC">
            <option value="WINNING">WINNING</option>
            <option value="BURNED">BURNED</option>
            <option value="TESTING">TESTING</option>
            <option value="TEST AGAIN">TEST AGAIN</option>
            <option value="TESTED">TESTED</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
        <div class="col-md-1">
          <img src="flags/burkinafaso.png" alt="Burkina Faso Flag" class="country-flag">
        </div>
        <div class="col-md-5">
          <label for="burkina">Burkina Faso:</label>
          <select class="form-control" name="statusBurkina">
            <option value="WINNING">WINNING</option>
            <option value="BURNED">BURNED</option>
            <option value="TESTING">TESTING</option>
            <option value="TEST AGAIN">TEST AGAIN</option>
            <option value="TESTED">TESTED</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
      </div>
    </div>
  </form>
</div>
	
<!-- Work Progression Tab -->
<div class="tab-pane" id="workProgression" role="tabpanel">
  <form id="workProgressionForm">
    <div class="form-group">
      <div class="input-group mb-3">
        <select id="FormCountryFilter" class="form-control">
		<option value="Ivory Coast">Ivory Coast</option>
		<option value="Senegal">Senegal</option>
		<option value="Mali">Mali</option>
		<option value="Gabon">Gabon</option>
		<option value="Guinea Conakry">Guinea Conakry</option>
		<option value="Gambia">Gambia</option>
		<option value="Cameroon">Cameroon</option>
		<option value="Argentina">Argentina</option>
		<option value="RDC">RDC</option>
		<option value="Burkina Faso">Burkina Faso</option>
		<!-- Add other countries as options -->
        </select>
        <div class="input-group-append">
          <button class="btn btn-primary" onclick="FilterCountry(event)">Filter</button>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label>Videos Ads:</label>
          <select class="form-control" name="videosAds">
                  <option value="N/A">N/A</option>
                  <option value="inprogress">IN PROGRESS</option>
                  <option value="finished">FINISHED</option>
          </select>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label>Voice Over:</label>
          <select class="form-control" name="voiceOver">
                  <option value="N/A">N/A</option>
                  <option value="inprogress">IN PROGRESS</option>
                  <option value="finished">FINISHED</option>
          </select>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label>Thumbnails:</label>
          <select class="form-control" name="thumbnails">
                  <option value="N/A">N/A</option>
                  <option value="inprogress">IN PROGRESS</option>
                  <option value="finished">FINISHED</option>
          </select>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label>LP/PP:</label>
          <select class="form-control" name="lppp">
                  <option value="N/A">N/A</option>
                  <option value="inprogress">IN PROGRESS</option>
                  <option value="finished">FINISHED</option>
          </select>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label>Adcopy:</label>
          <select class="form-control" name="adcopy">
                  <option value="N/A">N/A</option>
                  <option value="inprogress">IN PROGRESS</option>
                  <option value="finished">FINISHED</option>
          </select>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label>Reviews:</label>
          <select class="form-control" name="reviews">
                  <option value="N/A">N/A</option>
                  <option value="inprogress">IN PROGRESS</option>
                  <option value="finished">FINISHED</option>
          </select>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label>Product Price:</label>
      <input type="text" class="form-control" name="productPrice" placeholder="Enter Product Price">
    </div>
  </form>
</div>

 <!-- Creatives Tab -->
<div class="tab-pane" id="creatives" role="tabpanel">
  <form id="creativesForm">
    <div class="form-group">
      <div class="row">
        <div class="col-md-6">
          <label>Inspiration Videos Links:</label>
          <textarea class="form-control" name="adlibrary" rows="4" placeholder="Enter links"></textarea>
        </div>
        <div class="col-md-6">
          <label>Competitors LP/PP Links:</label>
          <textarea class="form-control" name="competitorslp/pp" rows="4" placeholder="Enter links"></textarea>
        </div>
      </div>
    </div>

    <div class="form-group">
      <div class="row">
        <div class="col-md-6">
          <label>Alibaba/Aliexpress Links:</label>
          <textarea class="form-control" name="alibaba/aliexpresslinks" rows="4" placeholder="Enter links"></textarea>
        </div>
        <div class="col-md-6">
          <label>Alibaba/Aliexpress Price:</label>
          <input type="text" class="form-control" name="alibabaaliexpressprice" placeholder="Enter Product Price">
        </div>
      </div>
    </div>

    <div class="form-group">
      <div class="row">
        <div class="col-md-6">
          <label>My LP/PP Link:</label>
          <textarea class="form-control" name="mylp/pplink" rows="4" placeholder="Enter link"></textarea>
        </div>
        <div class="col-md-6">
          <label>My AD Copy:</label>
          <textarea class="form-control" name="myadcopy" rows="4" placeholder="Enter Adcopy"></textarea>
        </div>
      </div>
    </div>

    <div class="form-group">
      <div class="row">
        <div class="col">
          <label>My Voice Over Script:</label>
          <textarea class="form-control" name="myvoiceoverscript" rows="5" placeholder="Voice Over Script"></textarea>
        </div>
      </div>
    </div>
  </form>
</div>

<!-- Sourcing Tab -->
<div class="tab-pane" id="sourcing" role="tabpanel">
  <form id="sourcingForm">
    <div class="form-group">
      <div class="row">
        <div class="col-md-12">
          <label>Supplier Name:</label>
          <input type="text" class="form-control" name="suppliername" placeholder="Supplier Name">
        </div>
      </div>
    </div>
    <div class="form-group">
      <div class="row">
        <div class="col-md-12">
          <label>Sourcing Price:</label>
          <input type="text" class="form-control" name="sourcingprice" placeholder="Sourcing Price">
        </div>
      </div>
    </div>
    <div class="form-group">
      <div class="row">
        <div class="col-md-12">
          <label>Product Weight:</label>
          <input type="text" class="form-control" name="productweight" placeholder="Product Weight">
        </div>
      </div>
    </div>
  </form>
</div>


            <!-- Add more tab content as needed -->
          </div>
        </div>

        <!-- Modal Footer -->
        <div class="modal-footer justify-content-center">
          <button type="button" id="saveProductButton" class="btn btn-primary" onclick="saveProduct()">SAVE</button>
          <button type="button" id="deleteProductButton" class="btn btn-danger" onclick="deleteProduct()">DELETE PRODUCT</button>
        </div>
      </div>
    </div>
  </div>
<footer class="footer">
    <p class="footer-text">
        Copyright © 2024 All rights reserved
    </p>
    <p class="footer-text">
        <span class="heart-symbol">&#10084;</span>
        Made with love by: AIMAD HIAD
    </p>
</footer>
  </div>
  </body>
</html>
<script>
  // Declare productDetails as a global variable
  var productDetails;
// Function to fetch product details by product ID
function fetchProductDetails(productId) {
    $.ajax({
        type: 'GET',
        url: 'get_product_details.php',
        data: { productId: productId },
        dataType: 'json',
        success: function (response) {
            console.log('Product details for ID ' + productId + ':', response);
            // Populate the edit form with the fetched product details
            populateEditForm(response);
            // Assign the fetched product details to the global variable
            productDetails = response;

            // Attach click event to the product image for triggering file input
            $('#productImagePreview').on('click', function () {
                $('#productImageInput').click();
            });

            // Attach change event to file input for handling file selection
            $('#productImageInput').on('change', handleProductImageChange);
        },
        error: function (error) {
            console.error('Error fetching product details:', error);
            // Handle error (e.g., show an alert)
        }
    });
}

// Function to handle product image change
function handleProductImageChange() {
    const fileInput = document.getElementById('productImageInput');
    const previewImage = document.getElementById('productImagePreview');

    const file = fileInput.files[0];
    if (file) {
        // Read the selected file
        const reader = new FileReader();
        reader.onload = function (e) {
            // Set the preview image source to the selected file
            previewImage.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
}

// Function to display product image
function displayProductImage(imageURL) {
  // Assuming you have an img tag with id 'productImage'
  $('#productImage').attr('src', imageURL);
}

 // Function to set default value for the "Work Progression" dropdown
  function setDefaultWorkProgression() {
    document.getElementById('FormCountryFilter').value = 'Ivory Coast';
  }
// Function to handle the "Edit" button click
function editProduct(productId) {
    // Check if Product Name is empty
    // Fetch product details before showing the modal
    fetchProductDetails(productId);

    // Show the edit product modal
    $('#editProductModal').modal('show');
    $('#productNameErrorEdit').text('Product Name is required!').hide();

    // Call the function to set the default value when the page loads
    setDefaultWorkProgression();

    // Call the function to update the form with product details
    updateEditForm();

    // Set the product ID for the "DELETE PRODUCT" button using the on method
    $('#deleteProductButton').off('click').on('click', function() {
        deleteProduct(productId);
    });

    // Reset the values of Videos Ads, Voice Over, Thumbnails, LP/PP, Adcopy, and Reviews dropdowns
    resetCreativeDropdowns();

    // Programmatically click on the "General Info" tab
    $('#generalInfoTab').tab('show');
}

   // Function to update the "Edit Product" form with product details
  function updateEditForm() {
    // Check if productDetails is available
    if (productDetails) {
      // Populate the edit form with the fetched product details
      populateEditForm(productDetails);
    } else {
      // Handle the case when product details are not available
      console.error('Product details not available.');
      // You might want to display an error message or handle it differently
    }
  }
  // Function to populate the edit form with product details
  function populateEditForm(productDetails) {
    // Populate general product details
    $('#productName').val(productDetails.ProductName);
    $('#doTest').val(productDetails.DoTest);
  // Populate country-specific test results for each country
  populateCountryStatus(productDetails, 'Ivory Coast', 'statusIvoryCoast');
  populateCountryStatus(productDetails, 'Senegal', 'statusSenegal');
  populateCountryStatus(productDetails, 'Mali', 'statusMali');
  populateCountryStatus(productDetails, 'Gabon', 'statusGabon');
  populateCountryStatus(productDetails, 'Guinea Conakry', 'statusGuinea');
  populateCountryStatus(productDetails, 'Gambia', 'statusGambia');
  populateCountryStatus(productDetails, 'Cameroon', 'statusCameroon');
  populateCountryStatus(productDetails, 'Argentina', 'statusArgentina');
  populateCountryStatus(productDetails, 'RDC', 'statusRDC');
  populateCountryStatus(productDetails, 'Burkina Faso', 'statusBurkina');
    // Populate other form fields as needed
    $('input[name="productPrice"]').val(productDetails.ProductPrice);
    $('textarea[name="notes"]').val(productDetails.Notes);
	$('textarea[name="adlibrary"]').val(productDetails.AdlibraryInspirationVideos);
	$('textarea[name="competitorslp/pp"]').val(productDetails.CompetitorsLinks);
	$('textarea[name="alibaba/aliexpresslinks"]').val(productDetails.AlibabaAliexpressLinks);
	$('input[name="alibabaaliexpressprice"]').val(productDetails.AlibabaAliexpressPrice);
	$('textarea[name="mylp/pplink"]').val(productDetails.MyLpPpLink);
	$('textarea[name="myadcopy"]').val(productDetails.MyAdCopy);
	$('textarea[name="myvoiceoverscript"]').val(productDetails.MyVoiceOverScript);
    // Populate the "Sourcing" section as needed
    $('input[name="suppliername"]').val(productDetails.SupplierName);
    $('input[name="sourcingprice"]').val(productDetails.SourcingPrice);
    $('input[name="productweight"]').val(productDetails.ProductWeight);
  // Populate country-specific test results
  for (var i = 0; i < productDetails.CountryStatus.length; i++) {
    var countryStatus = productDetails.CountryStatus[i];
    // Correctly construct the name of the status dropdown based on the country name
    $('select[name="status' + countryStatus.Country.replace(/ /g, '') + '"]').val(countryStatus.Status);
  }
      // Prevent the default form submission
    event.preventDefault();
    // Get the selected country from the filter dropdown
    var selectedCountry = $('#FormCountryFilter').val();
    // Find the country in the product details
    var countryDetails = productDetails.CountryStatus.find(function (country) {
      return country.Country === selectedCountry;
    });
    // Update the "Product Price" field with the selected country's price
    if (countryDetails) {
      $('input[name="productPrice"]').val(countryDetails.ProductPrice);
      // Update the dropdowns with the selected country's status
      updateDropdown('videosAds', countryDetails.VideosAdsStatus);
      updateDropdown('voiceOver', countryDetails.VoiceOverStatus);
      updateDropdown('thumbnails', countryDetails.ThumbnailsStatus);
      updateDropdown('lppp', countryDetails.LpPpStatus);
      updateDropdown('adcopy', countryDetails.AdCopyStatus);
      updateDropdown('reviews', countryDetails.ReviewsStatus);
    } else {
      // If the selected country is not found, you may want to handle this case
      $('input[name="productPrice"]').val('');
      updateDropdown('videosAds', ''); // Set the dropdown to an empty value
      updateDropdown('voiceOver', ''); // Set the dropdown to an empty value
      updateDropdown('thumbnails', ''); // Set the dropdown to an empty value
      updateDropdown('lppp', ''); // Set the dropdown to an empty value
      updateDropdown('adcopy', ''); // Set the dropdown to an empty value
      updateDropdown('reviews', ''); // Set the dropdown to an empty value
    }
	// Populate product image
	var productImage = productDetails.ProductImage; // Assuming 'ProductImage' is the correct field name
	if (productImage) {
		// Set the product image source
		$('#productImagePreview').attr('src', productImage);
		
		// Add rounded corners to the image
		$('#productImagePreview').css('border-radius', '10px'); // Adjust the radius as needed
	} else {
		// If there is no product image, you may want to set a default image or hide the image element
		$('#productImagePreview').attr('src', ''); // Set a default image path or an empty string
		// Alternatively, you can hide the image element
		// $('#productImagePreview').hide();
	}
  }
// Function to populate the status dropdown for a specific country
function populateCountryStatus(productDetails, countryName, dropdownName) {
  // Find the country in the CountryStatus array
  const countryStatus = productDetails.CountryStatus.find(country => country.Country === countryName);
  // Set the status in the dropdown if found, otherwise set it to an empty string or a default value
  $(`select[name="${dropdownName}"]`).val(countryStatus ? countryStatus.Status : '');
}
  // Your existing code for fetching and updating products table
function fetchProducts() {
    // Get filter values
    var countryFilter = document.getElementById('countryFilter').value;
    var doTestFilter = document.getElementById('doTestFilter').value;
    var statusFilter = document.getElementById('statusFilter').value;
    console.log('Filters:', countryFilter, doTestFilter, statusFilter);

    // Make an AJAX request to the server-side script
    $.ajax({
        type: 'GET',
        url: 'products.php',
        data: { country: countryFilter, doTest: doTestFilter, status: statusFilter },
        dataType: 'json',
        success: function (response) {
            console.log('Response from server:', response);

            // Sort products by timestamp in descending order
            response.sort(function (a, b) {
                return new Date(b.timestamp) - new Date(a.timestamp);
            });

            // Update the products table with the fetched data
            updateProductsTable(response);
        },
        error: function (error) {
            console.error('Error fetching products:', error);
            // Display an error message in the table
            displayErrorMessage('Error fetching products');
        }
    });
}
// Modify the fetchAllProducts function to accept parameters
function fetchAllProducts(countryFilter, doTestFilter, statusFilter) {
    // Log filter values (for debugging)
    console.log('Filters:', countryFilter, doTestFilter, statusFilter);

    // Make an AJAX request to the server-side script
    $.ajax({
        type: 'GET',
        url: 'products.php',
        data: { country: countryFilter, doTest: doTestFilter, status: statusFilter },
        dataType: 'json',
        success: function (response) {
            console.log('Response from server:', response);
            // Update the products table with the fetched data
            updateProductsTable(response);
        },
        error: function (error) {
            console.error('Error fetching products:', error);
            // Display an error message in the table
            displayErrorMessage('Error fetching products');
        }
    });
}
// Define a function to get the color based on the country status
function getCountryStatusColor(countryStatus) {
    switch (countryStatus) {
        case 'WINNING':
            return 'green'; // Set the color for 'WINNING'
        case 'BURNED':
            return 'red'; // Set the color for 'BURNED'
        case 'TESTING':
            return 'orange'; // Set the color for 'TESTING'
        case 'TESTED':
            return 'blue'; // Set the color for 'TESTED'
        case 'TEST AGAIN':
            return 'purple'; // Set the color for 'TEST AGAIN'
        case 'N/A':
            return 'gray'; // Set the color for 'N/A'
        default:
            return 'black'; // Default color if the country status doesn't match any case
    }
}
// Function to update the products table
function updateProductsTable(products) {
    // Sort products array by ProductID in descending order (newest to oldest)
    products.sort(function (a, b) {
        return b.ProductID - a.ProductID;
    });

    var tableBody = document.getElementById('productsTableBody');
    tableBody.innerHTML = ''; // Clear existing rows

    // Check if products are not empty
    if (products.length > 0) {
        // Iterate through the sorted products and create rows
        for (var i = 0; i < products.length; i++) {
            var product = products[i];

	// Combine status for all countries
	var combinedStatus = product.CountryStatus.map(function (countryStatus) {
		// Remove spaces from the country name and adjust the file extension
		var cleanedCountryName = countryStatus.Country.replace(/\s+/g, ''); // Remove spaces
		var flagFileName = 'flags/' + cleanedCountryName.toLowerCase() + '.png'; // Adjust the file extension if needed
		var flagStyle = 'width: 20px; height: auto;'; // Adjust the width to your preference

		var statusStyle;
		var statusText;

		switch (countryStatus.Status) {
			case 'WINNING':
				statusStyle = 'color: green; font-weight: bold;';
				statusText = 'WINNING';
				break;
			case 'N/A':
				statusStyle = 'color: black; font-weight: normal;';
				statusText = 'N/A';
				break;
			case 'BURNED':
				statusStyle = 'color: orange; font-weight: bold;';
				statusText = 'BURNED';
				break;
			case 'TESTING':
				statusStyle = 'color: blue; font-weight: bold;';
				statusText = 'TESTING';
				break;
			case 'TESTED':
				statusStyle = 'color: purple; font-weight: bold;';
				statusText = 'TESTED';
				break;
			case 'TEST AGAIN':
				statusStyle = 'color: brown; font-weight: bold;';
				statusText = 'TEST AGAIN';
				break;
			default:
				statusStyle = 'color: red; font-weight: normal;';
				statusText = countryStatus.Status;
		}

		return '<div class="country-status">' +
			'<img src="' + flagFileName + '" alt="Flag" class="country-flag" style="' + flagStyle + '">' +
			' ' + // Add a space here
			countryStatus.Country + ': <span style="' + statusStyle + '">' + statusText + '</span>' +
			'</div>';
	}).join('');


		// Create a row with checkbox, product name, and status in the same cell
		var row =
			'<tr class="product-row" data-product-id="' +
			product.ProductID +
			'">' +
			'<td class="product-name">' +
			'<div class="product-image"><img src="' + product.ProductImage + '" alt="Product Image" style="max-width: 200px; border-radius: 10px;"></div>' + // Adjust the border-radius value as needed
			'<input type="checkbox" class="product-checkbox" data-product-id="' +
			product.ProductID +
			'">&nbsp;&nbsp;' +
			product.ProductName +
			'</td>' +
			'<td>' +
			'<span class="do-test-symbol" style="color: ' + getColor(product.DoTest) + ';">' + getTestStatus(product.DoTest) + '</span>' +
			'</td>' +
			'<td style="text-align: left;">' +
			combinedStatus +
			'</td>' +
			'<td>' +
			product.SourcingPrice +
			'</td>' +
			'<td>' +
			'<button class="btn btn-info" onclick="editProduct(' +
			product.ProductID +
			')">Edit</button> ' +
			'<button class="btn btn-danger" id="deleteProductButton" onclick="deleteProduct(' +
			product.ProductID +
			')">Delete</button>' +
			'<button class="btn btn-success" id="duplicateProductButton" onclick="duplicateProduct(' +
			product.ProductID +
			')">Duplicate</button>' +
			'</td>' +
			'</tr>';

            tableBody.innerHTML += row;
        }

        // Functions to determine color and status based on the value
        function getColor(doTest) {
            return doTest === 'YES' ? 'green' : (doTest === 'NO' ? 'red' : 'gray');
        }

        function getTestStatus(doTest) {
            return doTest === 'YES' ? '✔️ YES' : (doTest === 'NO' ? '❌ NO' : 'N/A');
        }
    } else {
        // If no products found, display a message in the table
        displayErrorMessage('No records found');
    }

    // Add "Select All" checkbox with arrow icons
    var selectAllCheckbox =
        '<div class="sticky-container">' +
        '<label>' +
        '<input type="checkbox" id="selectAllCheckbox">' +
        '<i class="unchecked-icon far fa-arrow-alt-circle-down"></i>' +
        '<i class="checked-icon fas fa-arrow-alt-circle-up"></i>' +
        'Select All' +
        '</label>' +
        '</div>';
    $('#productsTable').before(selectAllCheckbox);

    // Add event listener to "Select All" checkbox
    $('#selectAllCheckbox').on('change', function () {
        var isChecked = $(this).prop('checked');
        // Set all product checkboxes to the same state as "Select All"
        $('.product-checkbox').prop('checked', isChecked);

        // Update icon based on checkbox state
        updateSelectAllIcon(isChecked);
        updateCreateNewProductButtonState(); // Update button state
    });

    // Add event listener to rows for checkbox selection on row click
    $('.product-row').on('click', function (e) {
        // Exclude checkbox clicks
        if (e.target.type !== 'checkbox') {
            var productId = $(this).data('product-id');
            var checkbox = $(this).find('.product-checkbox');

            // Toggle the checkbox state
            checkbox.prop('checked', !checkbox.prop('checked'));

            // Update the "Select All" checkbox state based on the number of selected checkboxes
            updateSelectAllCheckboxState();
            updateCreateNewProductButtonState(); // Update button state
        }
    });
}


// Add event listener to the search input
$('#searchProduct').on('input', function () {
    filterProducts();
});
// Function to update the "Select All" checkbox state based on the number of selected checkboxes
function updateSelectAllCheckboxState() {
  var totalCheckboxes = $('.product-checkbox').length;
  var checkedCheckboxes = $('.product-checkbox:checked').length;
  $('#selectAllCheckbox').prop('checked', totalCheckboxes === checkedCheckboxes);
}
// Function to update the "CREATE NEW PRODUCT" button state based on the number of selected checkboxes
function updateCreateNewProductButtonState() {
  var selectedCheckboxes = $('.product-checkbox:checked').length;
  var deleteSelectedProductsButton = $('#deleteSelectedProductsButton');
  deleteSelectedProductsButton.prop('disabled', selectedCheckboxes === 0);
}
// Function to update the "Select All" checkbox icon based on its state
function updateSelectAllIcon(isChecked) {
  var icon = isChecked ? 'checked-icon' : 'unchecked-icon';
  $('#selectAllCheckbox').next('i').attr('class', 'far fa-arrow-alt-circle-down ' + icon);
}
// Function to update "Select All" icon based on checkbox state
function updateSelectAllIcon(isChecked) {
  var uncheckedIcon = isChecked ? 'far fa-arrow-alt-circle-up' : 'far fa-arrow-alt-circle-down';
  var checkedIcon = 'fas fa-arrow-alt-circle-up';
  $('.unchecked-icon').attr('class', uncheckedIcon);
  $('.checked-icon').attr('class', checkedIcon);
}
  // Function to display an error message in the table
  function displayErrorMessage(message) {
    var tableBody = document.getElementById('productsTableBody');
    tableBody.innerHTML = '<tr><td colspan="5">' + message + '</td></tr>';
  }

  // Function to apply filters and fetch products when the SEARCH button is clicked
  function applyFilters() {
    fetchProducts();
  }
  fetchProducts();
  // Function to apply filters and fetch products when the SEARCH ALL button is clicked
function applyAllFilters() {
    // Get filter values
    var countryFilter = 'ALL';
    var doTestFilter = 'ALL';
    var statusFilter = 'ALL';

    // Call fetchAllProducts with the specified filters
    fetchAllProducts(countryFilter, doTestFilter, statusFilter);
	// Set filter values to "ALL"
    document.getElementById('countryFilter').selectedIndex = 0; // Assuming "ALL" is the first option
    document.getElementById('doTestFilter').selectedIndex = 0;  // Assuming "ALL" is the first option
    document.getElementById('statusFilter').selectedIndex = 0;  // Assuming "ALL" is the first option
}
    fetchAllProducts();
   // Function to handle the "Filter" button click for Country
  function FilterCountry(event) {
    // Prevent the default form submission
    event.preventDefault();
    // Get the selected country from the filter dropdown
    var selectedCountry = $('#FormCountryFilter').val();
    // Find the country in the product details
    var countryDetails = productDetails.CountryStatus.find(function (country) {
      return country.Country === selectedCountry;
    });
    // Update the "Product Price" field with the selected country's price
    if (countryDetails) {
      $('input[name="productPrice"]').val(countryDetails.ProductPrice);
      // Update the dropdowns with the selected country's status
      updateDropdown('videosAds', countryDetails.VideosAdsStatus);
      updateDropdown('voiceOver', countryDetails.VoiceOverStatus);
      updateDropdown('thumbnails', countryDetails.ThumbnailsStatus);
      updateDropdown('lppp', countryDetails.LpPpStatus);
      updateDropdown('adcopy', countryDetails.AdCopyStatus);
      updateDropdown('reviews', countryDetails.ReviewsStatus);
    } else {
      // If the selected country is not found, you may want to handle this case
      $('input[name="productPrice"]').val('');
      updateDropdown('videosAds', ''); // Set the dropdown to an empty value
      updateDropdown('voiceOver', ''); // Set the dropdown to an empty value
      updateDropdown('thumbnails', ''); // Set the dropdown to an empty value
      updateDropdown('lppp', ''); // Set the dropdown to an empty value
      updateDropdown('adcopy', ''); // Set the dropdown to an empty value
      updateDropdown('reviews', ''); // Set the dropdown to an empty value
    }
  }
  // Function to update a dropdown with the specified value
  function updateDropdown(dropdownName, selectedValue) {
    // Get the dropdown element by name
    var dropdown = $('select[name="' + dropdownName + '"]');
    // Get the existing options in the dropdown
    var existingOptions = dropdown.children();
    // Clear the existing options
    dropdown.empty();
    // Define the possible status values
    var statusValues = ['N/A', 'IN PROGRESS', 'FINISHED'];
    // Iterate through the status values and add options to the dropdown
    for (var i = 0; i < statusValues.length; i++) {
      var statusValue = statusValues[i];
      var option = $('<option>', { value: statusValue, text: statusValue });
      // Append the option to the dropdown
      dropdown.append(option);
    }
    // Set the selected value in the dropdown
    dropdown.val(selectedValue);
  }
 // Function to reset the values of Videos Ads, Voice Over, Thumbnails, LP/PP, Adcopy, and Reviews dropdowns
function resetCreativeDropdowns() {
  $('select[name="videosAds"]').val('N/A');
  $('select[name="voiceOver"]').val('N/A');
  $('select[name="thumbnails"]').val('N/A');
  $('select[name="lppp"]').val('N/A');
  $('select[name="adcopy"]').val('N/A');
  $('select[name="reviews"]').val('N/A');
}
// Function to handle the "SAVE" button click
function saveProduct() {
    // Get the product ID
    var productId = productDetails.ProductID;
    // Get the updated values from the form
    var updatedProductName = $('#productName').val().trim(); // Trim leading and trailing whitespaces

    // Check if Product Name is empty
    if (!updatedProductName) {
        // Display an error message below the Product Name input
        $('#productNameErrorEdit').text('Product Name is required!').show();
        return; // Stop execution if there's an error
    }

    // Get the updated values from the form
    var updatedDoTest = $('#doTest').val();
    // Get the updated status for Ivory Coast
    var updatedStatusIvoryCoast = $('select[name="statusIvoryCoast"]').val();
    var updatedStatusSENEGAL = $('select[name="statusSenegal"]').val();
    var updatedStatusMALI = $('select[name="statusMali"]').val();
    var updatedStatusGUINEA = $('select[name="statusGuinea"]').val();
    var updatedStatusGAMBIA = $('select[name="statusGambia"]').val();
    var updatedStatusBURKINA = $('select[name="statusBurkina"]').val();
    var updatedStatusCAMEROON = $('select[name="statusCameroon"]').val();
    var updatedStatusARGENTINA = $('select[name="statusArgentina"]').val();
    var updatedStatusRDC = $('select[name="statusRDC"]').val();
    var updatedStatusGABON = $('select[name="statusGabon"]').val();

    var updatedNotes = $('textarea[name="notes"]').val();

    var updatedSupplierName = $('input[name="suppliername"]').val();
    var updatedSourcingPrice = $('input[name="sourcingprice"]').val();
    var updatedProductWeight = $('input[name="productweight"]').val();

    var updatedAdlibraryInspirationVideos = $('textarea[name="adlibrary"]').val();
    var updatedCompetitorsLPPLinks = $('textarea[name="competitorslp/pp"]').val();
    var updatedAlibabaAliexpressLinks = $('textarea[name="alibaba/aliexpresslinks"]').val();
    var updatedAlibabaAliexpressPrice = $('input[name="alibabaaliexpressprice"]').val();
    var updatedMyLpPpLink = $('textarea[name="mylp/pplink"]').val();
    var updatedMyAdCopy = $('textarea[name="myadcopy"]').val();
    var updatedMyVoiceOverScript = $('textarea[name="myvoiceoverscript"]').val();

    // Get the value of the filter form for the country
    var selectedCountry = $('#FormCountryFilter').val();

    var updatedVideosAds = $('select[name="videosAds"]').val();
    var updatedVoiceOver = $('select[name="voiceOver"]').val();
    var updatedThumbnails = $('select[name="thumbnails"]').val();
    var updatedLppp = $('select[name="lppp"]').val();
    var updatedAdcopy = $('select[name="adcopy"]').val();
    var updatedReviews = $('select[name="reviews"]').val();
    var updatedProductprice = $('input[name="productPrice"]').val();

    // Create an object with the updated data
// Create an object with the updated data
var updatedProductData = {
    productId: productId,
    productName: updatedProductName,
    doTest: updatedDoTest,
    statusIvoryCoast: updatedStatusIvoryCoast,
    statusSenegal: updatedStatusSENEGAL,
    statusMali: updatedStatusMALI,
    statusGuinea: updatedStatusGUINEA,
    statusGabon: updatedStatusGABON,
    statusGambia: updatedStatusGAMBIA,
    statusBurkina: updatedStatusBURKINA,
    statusCameroon: updatedStatusCAMEROON,
    statusRDC: updatedStatusRDC,
    statusArgentina: updatedStatusARGENTINA,

    supplierName: updatedSupplierName,
    sourcingPrice: updatedSourcingPrice,
    productWeight: updatedProductWeight,

    notes: updatedNotes,

    // Encode textarea values to handle special characters
    adlibraryInspirationVideos: encodeURIComponent(updatedAdlibraryInspirationVideos),
    competitorsLPPLinks: encodeURIComponent(updatedCompetitorsLPPLinks),
    alibabaAliexpressLinks: encodeURIComponent(updatedAlibabaAliexpressLinks),
    alibabaAliexpressPrice: updatedAlibabaAliexpressPrice,
    myLpPpLink: encodeURIComponent(updatedMyLpPpLink),
    myAdCopy: encodeURIComponent(updatedMyAdCopy),
    myVoiceOverScript: encodeURIComponent(updatedMyVoiceOverScript),

    selectedCountry: selectedCountry,
    videosAds: updatedVideosAds,
    voiceOver: updatedVoiceOver,
    thumbnails: updatedThumbnails,
    lppp: updatedLppp,
    adcopy: updatedAdcopy,
    reviews: updatedReviews,
    productPrice: updatedProductprice,
};


    // Get the product image file from the input
    const imageFile = document.getElementById('productImageInput').files[0];

    // Check if a new image file is selected
    if (imageFile) {
        // Create a FormData object to send both text and file data
        const formData = new FormData();
        formData.append('productId', productId);
        formData.append('productName', updatedProductName);
        formData.append('doTest', updatedDoTest);
        formData.append('statusIvoryCoast', updatedStatusIvoryCoast);
        formData.append('statusSenegal', updatedStatusSENEGAL);
        formData.append('statusMali', updatedStatusMALI);
        formData.append('statusGuinea', updatedStatusGUINEA);
        formData.append('statusGabon', updatedStatusGABON);
        formData.append('statusGambia', updatedStatusGAMBIA);
        formData.append('statusBurkina', updatedStatusBURKINA);
        formData.append('statusCameroon', updatedStatusCAMEROON);
        formData.append('statusRDC', updatedStatusRDC);
        formData.append('statusArgentina', updatedStatusARGENTINA);

        formData.append('notes', updatedNotes);

        formData.append('supplierName', updatedSupplierName);
        formData.append('sourcingPrice', updatedSourcingPrice);
        formData.append('productWeight', updatedProductWeight);

        formData.append('adlibraryInspirationVideos', updatedAdlibraryInspirationVideos);
        formData.append('competitorsLPPLinks', updatedCompetitorsLPPLinks);
        formData.append('alibabaAliexpressLinks', updatedAlibabaAliexpressLinks);
        formData.append('alibabaAliexpressPrice', updatedAlibabaAliexpressPrice);
        formData.append('myLpPpLink', updatedMyLpPpLink);
        formData.append('myAdCopy', updatedMyAdCopy);
        formData.append('myVoiceOverScript', updatedMyVoiceOverScript);

        formData.append('selectedCountry', selectedCountry);
        formData.append('videosAds', updatedVideosAds);
        formData.append('voiceOver', updatedVoiceOver);
        formData.append('thumbnails', updatedThumbnails);
        formData.append('lppp', updatedLppp);
        formData.append('adcopy', updatedAdcopy);
        formData.append('reviews', updatedReviews);
        formData.append('productPrice', updatedProductprice);

        // Append the new image file to formData
        formData.append('productImage', imageFile);

        // Make an AJAX request to save the updated product data with the new image
        $.ajax({
            type: 'POST',
            url: 'save_product.php', // Replace with the actual server-side script
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                console.log('Product updated successfully:', response);
                // Optionally, you can update the local productDetails variable with the updated data
                // Update other fields in productDetails as needed
                // Optionally, you can also update the products table or perform any other actions
                fetchProducts(); // Fetch and update the products table
                // Hide the edit product modal
                $('#editProductModal').modal('hide');
            },
            error: function (error) {
                console.error('Error updating product:', error);
                // Handle the error (e.g., display an alert)
            }
        });
    } else {
        // If no new image is selected, proceed with updating other data only
        // Make an AJAX request to save the updated product data
        $.ajax({
            type: 'POST',
            url: 'save_product.php', // Replace with the actual server-side script
            data: updatedProductData,
            dataType: 'json',
            success: function (response) {
                console.log('Product updated successfully:', response);
                // Optionally, you can update the local productDetails variable with the updated data
                // Update other fields in productDetails as needed
                // Optionally, you can also update the products table or perform any other actions
                fetchProducts(); // Fetch and update the products table
                // Hide the edit product modal
                $('#editProductModal').modal('hide');
            },
            error: function (error) {
                console.error('Error updating product:', error);
                // Handle the error (e.g., display an alert)
            }
        });
    }
}

function deleteProduct(productId) {
    // Confirm the deletion with the user
    if (confirm("Are you sure you want to delete this product?")) {
    // Make an AJAX request to delete the product
    $.ajax({
        url: 'delete-product.php', // Replace with the correct path
        type: 'POST', // Change to 'POST' if your server expects POST requests
        data: { productIds: [productId] }, // Pass an array of product IDs
        success: function(response) {
            // Check if the deletion was successful
                if (response.success) {
                    console.log('Product deleted successfully:', response.message);
                    // Display a success message to the user
                    alert('Product deleted successfully');
                    // Optionally, you can update the products table or perform any other actions
                    fetchProducts(); // Fetch and update the products table

                    // If deleting from the edit form, hide the modal
                    $('#editProductModal').modal('hide');
                } else {
                    console.error('Error deleting product:', response.message);
                    // Handle the error (e.g., display an alert)
                }
            },
            error: function (error) {
                console.error('Error deleting product:', error);
                // Handle the error (e.g., display an alert)
            }
    });
    }
}
// Function to delete the selected products
function deleteSelectedProducts() {
  // Get the array of selected product IDs
  var selectedProductIds = $('.product-checkbox:checked').map(function () {
    return $(this).data('product-id');
  }).get();

  // Check if any products are selected
  if (selectedProductIds.length > 0) {
  
    // Confirm the deletion with the user
    if (confirm("Are you sure you want to delete the selected products?")) {
      // Make an AJAX request to delete the selected products using delete-product.php
	  $('#deleteSelectedProductsButton').prop('disabled', false);
      $.ajax({
        type: 'POST',
        url: 'delete-product.php', // Use the delete-product.php file
        data: { productIds: selectedProductIds },
        dataType: 'json',
        success: function (response) {
          if (response.success) {
            console.log('Selected products deleted successfully:', response.message);
            // Display a success message to the user
            alert('Selected products deleted successfully');
            // Optionally, you can update the products table or perform any other actions
            fetchProducts(); // Fetch and update the products table
          } else {
            console.error('Error deleting selected products:', response.message);
            // Handle the error (e.g., display an alert)
          }
        },
        error: function (error) {
          console.error('Error deleting selected products:', error);
          // Handle the error (e.g., display an alert)
        }
      });
    }
  } else {
    // If no products are selected, show a message
    //alert('No products selected for deletion.');
	//$('#deleteSelectedProductsButton').prop('disabled', true);
  }
}
// Function to handle the "DUPLICATE" button click
function duplicateProduct(productId) {
    // Confirm the duplication with the user
    if (confirm("Are you sure you want to duplicate this product?")) {
        // Make an AJAX request to duplicate the product
        $.ajax({
            type: 'POST',
            url: 'duplicate-product.php', // Replace with the actual server-side script
            data: { productId: productId },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    console.log('Product duplicated successfully:', response.message);
                    // Display a success message to the user
                    alert('Product duplicated successfully');
                    // Optionally, you can update the products table or perform any other actions
                    fetchProducts(); // Fetch and update the products table
                } else {
                    console.error('Error duplicating product:', response.message);
                    // Handle the error (e.g., display an alert)
                }
            },
            error: function (error) {
                console.error('Error duplicating product:', error);
                // Handle the error (e.g., display an alert)
            }
        });
    }
}
// Function to set default status for country filters
function setDefaultStatusForCountries() {
    $('select[name="FormCountryFilter"]').val('All');
}
// Function to set default status for a specific country in the form
function setDefaultStatusForCountry(countryName) {
    var dropdownName = 'status' + countryName.replace(/ /g, '');
    $('select[name="' + dropdownName + '"]').val('N/A');
}
// Function to set default status for creative elements
function setDefaultCreativeStatus() {
    $('select[name="videosAds"]').val('N/A');
    $('select[name="voiceOver"]').val('N/A');
    $('select[name="thumbnails"]').val('N/A');
    $('select[name="lppp"]').val('N/A');
    $('select[name="adcopy"]').val('N/A');
    $('select[name="reviews"]').val('N/A');
}
// Function to create a new product form
function createNewProductForm() {
    $('#createProductModal').modal('show');
    // Set default values for the form fields
    $('#NewproductName').val('Product for test');
    $('#NewdoTest').val('N/A'); // Set default value for Do-Test
    $('textarea[name="Newnotes"]').val('');
	$('#successMessage').text('Product created successfully!').hide();
	$('#productNameError').text('Product name is required!').hide();
    $('#saveProductButton')
        .css({
            'width': '100%', // Set the width to 100%
            'margin-top': '10px' // Add some top margin for spacing
        });
}
// Function to save a new product
function saveNewProduct() {
    // Get the value of the Product Name
    var newProductName = $('#NewproductName').val();

    // Check if the Product Name is not empty
    if (newProductName.trim() !== "") {
        // Clear any existing error message
        $('#productNameError').text('').hide();

        // Get the values from the other form fields
        var newDoTest = $('#NewdoTest').val();
        var newNotes = $('textarea[name="Newnotes"]').val();

        // Get the product image file
        var newProductImage = $('#newProductImage')[0].files[0];

        // Create a FormData object to send both text and file data
        var formData = new FormData();
        formData.append('NewproductName', newProductName);
        formData.append('NewdoTest', newDoTest);
        formData.append('Newnotes', newNotes);

        // Append the product image file to the FormData object
        if (newProductImage) {
            formData.append('newProductImage', newProductImage);
        }

        // Make an AJAX request to save the new product data
        $.ajax({
            type: 'POST',
            url: 'create_product.php',
            data: formData,
            contentType: false, // Don't set any content type
            processData: false, // Don't process the data
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    console.log('Product Created successfully', response.message);
                    // Display a success message to the user
                    $('#successMessage').text('Product created successfully!').show();
                } else {
                    console.error('Error creating product:', response.message);
                    // Handle the error (e.g., display an alert)
                }
            },
            error: function (error) {
                console.error('Error creating new product:', error);
                // Handle the error (e.g., display an alert)
            },
            complete: function () {
                // Fetch and update the products table regardless of success or failure
                fetchProducts();
            }
        });
    } else {
        // Display an error message below the Product Name input
        $('#productNameError').text('Product Name is required!').show();
    }
}



  function toggleSelectAll() {
    var selectAllCheckbox = document.getElementById("selectAllCheckbox");
    // You can add additional logic here if needed
  }
// Mapping of country names to flag file names
var countryFlagMap = {
    'Ivory Coast': 'flags/ivorycoast.PNG',
    'Mali': 'flags/mali.PNG',
    'Cameroon': 'flags/cameroon.PNG',
    'Gabon': 'flags/gabon.PNG',
    'Argentina': 'flags/argentina.PNG',
    'RDC': 'flags/rdc.PNG',
    'Senegal': 'flags/senegal.PNG',
    'Guinea Conakry': 'flags/guineaconakry.PNG',
    'Gambia': 'flags/gambia.PNG',
	'Burkina Faso': 'flags/burkinafaso.PNG',
};

// Function to get the flag file name based on the country name
function getFlagFileName(countryName) {
    // Use the mapping to get the flag file name
    return countryFlagMap[countryName] || '';
}

// Function to set default flag for a specific country in the form
function setDefaultFlagForCountry(countryName) {
    var flagFileName = getFlagFileName(countryName);
    if (flagFileName) {
        $('#countryFlag').attr('src', flagFileName);
    }
}

// Handle country selection
function selectCountry(country) {
    updateButtonText(country);
    setDefaultFlagForCountry(country);
}

// Update button text with the selected country and flag
function updateButtonText(country) {
    var flagFileName = getFlagFileName(country);
    document.getElementById('countryButtonText').innerText = country;
    $('#countryFlag').attr('src', flagFileName);
}

// Set Ivory Coast as default
$(document).ready(function() {
    selectCountry('Ivory Coast');
});
// Get the input fields and button
  var productNameInput = document.getElementById('NewproductName');
  var doTestSelect = document.getElementById('NewdoTest');
  var notesTextarea = document.getElementsByName('Newnotes')[0];
  var createButton = document.getElementById('saveProductButton'); // Adjust the ID based on your actual button ID

  // Add an event listener for the keypress event on the input fields
  productNameInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      // Prevent the default behavior of the Enter key
      e.preventDefault();

      // Trigger the click event on the create button
      createButton.click();
    }
  });

  doTestSelect.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      // Prevent the default behavior of the Enter key
      e.preventDefault();

      // Trigger the click event on the create button
      createButton.click();
    }
  });

  notesTextarea.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      // Prevent the default behavior of the Enter key
      e.preventDefault();

      // Trigger the click event on the create button
      createButton.click();
    }
  });
// Function to display the image preview
  function displayImagePreview() {
    const preview = document.getElementById('imagePreview');
    const container = document.getElementById('imagePreviewContainer');
    const fileInput = document.getElementById('newProductImage');
    const file = fileInput.files[0];

    if (file) {
      const reader = new FileReader();

      reader.onload = function (e) {
        preview.src = e.target.result;
        container.style.display = 'block'; // Show the container
      };

      reader.readAsDataURL(file);
    } else {
      // Clear the preview if no file is selected
      preview.src = '';
      container.style.display = 'none'; // Hide the container
    }
  }

  // Function to reset the file input value and hide the preview
  function resetFileInput() {
    document.getElementById('newProductImage').value = ''; // Clear file input value
    document.getElementById('imagePreview').src = ''; // Clear image preview source
    document.getElementById('imagePreviewContainer').style.display = 'none'; // Hide the container
  }

  // Reset file input when opening the create product form
  $('#createProductModal').on('show.bs.modal', function (e) {
    resetFileInput();
  });

  // Clear file input and image preview when the modal is hidden (closed)
  $('#createProductModal').on('hidden.bs.modal', function (e) {
    resetFileInput();
  });
function filterProducts() {
  var searchTerm = $('#searchProduct').val().toLowerCase();

  // Hide all product rows
  $('.product-row').hide();

  // Show only the product rows that match the search term
  $('.product-name').filter(function () {
    return $(this).text().toLowerCase().includes(searchTerm);
  }).closest('.product-row').show();
}
// </script>