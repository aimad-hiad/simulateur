<?php
require_once('db.php');

$productId = $_GET['productId'] ?? null;

if ($productId !== null) {
    // Fetch product details
    $productSql = "SELECT * FROM product WHERE ProductID = $productId";
    $productResult = $conn->query($productSql);

    if ($productResult->num_rows > 0) {
        $product = $productResult->fetch_assoc();

        // Fetch country status
        $countryStatusSql = "SELECT Country, Status, VideosAdsStatus, VoiceOverStatus, ThumbnailsStatus, 
                            LpPpStatus, AdCopyStatus, ReviewsStatus, ProductPrice
                            FROM countrystatus
                            WHERE ProductID = $productId";
        $countryStatusResult = $conn->query($countryStatusSql);

        $countryStatus = [];
        while ($csRow = $countryStatusResult->fetch_assoc()) {
            $countryStatus[] = $csRow;
        }

        // Add country status to the product data
        $product['CountryStatus'] = $countryStatus;

        // Fetch image URL
        $imageSql = "SELECT ProductImage FROM product WHERE ProductID = $productId";
        $imageResult = $conn->query($imageSql);
        $imageRow = $imageResult->fetch_assoc();

        // Add image URL to the product data
        $product['ProductImage'] = $imageRow['ProductImage'];

        // Output product details as JSON
        header('Content-Type: application/json');
        echo json_encode($product);
    } else {
        // Product not found
        header('HTTP/1.1 404 Not Found');
        echo json_encode(['error' => 'Product not found']);
    }
} else {
    // Invalid request
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Product ID is required']);
}

$conn->close();
?>
