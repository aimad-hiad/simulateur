<?php
require_once('db.php');

// Get data from the POST request
$productId = $_POST['productId'];

// Start a transaction
$conn->begin_transaction();

// Duplicate the product
$sqlDuplicateProduct = "INSERT INTO product (ProductName, DoTest, Notes, ProductImage, AdlibraryInspirationVideos, CompetitorsLinks, AlibabaAliexpressLinks, AlibabaAliexpressPrice, MyLpPpLink, MyAdCopy, MyVoiceOverScript, SupplierName, SourcingPrice, ProductWeight)
SELECT CONCAT(ProductName, ' (copy)'), DoTest, Notes, ProductImage, AdlibraryInspirationVideos, CompetitorsLinks, AlibabaAliexpressLinks, AlibabaAliexpressPrice, MyLpPpLink, MyAdCopy, MyVoiceOverScript, SupplierName, SourcingPrice, ProductWeight
FROM product
WHERE ProductID = $productId";

if ($result = $conn->query($sqlDuplicateProduct)) {
    // Get the ID of the newly inserted product
    $newProductId = $conn->insert_id;

    // Duplicate country statuses
    $sqlDuplicateCountryStatus = "INSERT INTO countrystatus (ProductID, Country, Status, VideosAdsStatus, VoiceOverStatus, ThumbnailsStatus, LpPpStatus, AdCopyStatus, ReviewsStatus, ProductPrice)
    SELECT $newProductId, Country, Status, VideosAdsStatus, VoiceOverStatus, ThumbnailsStatus, LpPpStatus, AdCopyStatus, ReviewsStatus, ProductPrice
    FROM countrystatus
    WHERE ProductID = $productId";

    if ($conn->query($sqlDuplicateCountryStatus) === TRUE) {
        // If the duplication is successful, commit the transaction
        $conn->commit();
        $response = array('success' => true, 'message' => 'Product duplicated successfully');
        echo json_encode($response);
    } else {
        // If there's an error in duplicating country statuses, rollback the transaction
        $conn->rollback();
        $response = array('success' => false, 'message' => 'Error duplicating country statuses: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    // If there's an error in duplicating the product, rollback the transaction
    $conn->rollback();
    $response = array('success' => false, 'message' => 'Error duplicating product: ' . $conn->error);
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>