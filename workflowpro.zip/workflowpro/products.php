<?php
// Include your database connection
include 'db.php';

$countryFilter = $_GET['country'] ?? 'ALL';
$doTestFilter = $_GET['doTest'] ?? 'ALL';
$statusFilter = $_GET['status'] ?? 'ALL';

// Adjusted the WHERE clause for filtering
$sql = "SELECT DISTINCT p.ProductID, p.ProductName, p.ProductImage, p.DoTest, p.Notes, p.AdlibraryInspirationVideos, p.CompetitorsLinks, p.AlibabaAliexpressLinks, p.AlibabaAliexpressPrice, p.MyLpPpLink, p.MyAdCopy, p.MyVoiceOverScript, p.SupplierName, p.SourcingPrice, p.ProductWeight,
        cs.Country, cs.Status, cs.VideosAdsStatus, cs.VoiceOverStatus, cs.ThumbnailsStatus, cs.LpPpStatus, cs.AdCopyStatus, cs.ReviewsStatus, cs.ProductPrice
        FROM product p
        LEFT JOIN countrystatus cs ON p.ProductID = cs.ProductID
        WHERE (cs.Country = '$countryFilter' OR '$countryFilter' = 'ALL' OR '$countryFilter' = '')
          AND (p.DoTest = '$doTestFilter' OR '$doTestFilter' = 'ALL' OR '$doTestFilter' = '')
          AND (cs.Status = '$statusFilter' OR '$statusFilter' = 'ALL' OR '$statusFilter' = '')";

$result = $conn->query($sql);

$products = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $productId = $row['ProductID'];

        // Check if the product already exists in the array
        $existingProduct = array_filter($products, function ($product) use ($productId) {
            return $product['ProductID'] == $productId;
        });

        if (empty($existingProduct)) {
            // Product does not exist, add it to the array
            $products[] = [
                'ProductID' => $productId,
                'ProductName' => $row['ProductName'],
                'ProductImage' => $row['ProductImage'], // Add this line to include the image path
                'DoTest' => $row['DoTest'],
                'Notes' => $row['Notes'],
                'AdlibraryInspirationVideos' => $row['AdlibraryInspirationVideos'],
                'CompetitorsLinks' => $row['CompetitorsLinks'],
                'AlibabaAliexpressLinks' => $row['AlibabaAliexpressLinks'],
                'AlibabaAliexpressPrice' => $row['AlibabaAliexpressPrice'],
                'MyLpPpLink' => $row['MyLpPpLink'],
                'MyAdCopy' => $row['MyAdCopy'],
                'MyVoiceOverScript' => $row['MyVoiceOverScript'],
                'SupplierName' => $row['SupplierName'],
                'SourcingPrice' => $row['SourcingPrice'],
                'ProductWeight' => $row['ProductWeight'],
                'CountryStatus' => [
                    [
                        'Country' => $row['Country'],
                        'Status' => $row['Status'],
                        'VideosAdsStatus' => $row['VideosAdsStatus'],
                        'VoiceOverStatus' => $row['VoiceOverStatus'],
                        'ThumbnailsStatus' => $row['ThumbnailsStatus'],
                        'LpPpStatus' => $row['LpPpStatus'],
                        'AdCopyStatus' => $row['AdCopyStatus'],
                        'ReviewsStatus' => $row['ReviewsStatus'],
                        'ProductPrice' => $row['ProductPrice'],
                    ],
                ],
            ];
        } else {
            // Product already exists, add country status to its CountryStatus
            $existingProductKey = key($existingProduct);
            $products[$existingProductKey]['CountryStatus'][] = [
                'Country' => $row['Country'],
                'Status' => $row['Status'],
                'VideosAdsStatus' => $row['VideosAdsStatus'],
                'VoiceOverStatus' => $row['VoiceOverStatus'],
                'ThumbnailsStatus' => $row['ThumbnailsStatus'],
                'LpPpStatus' => $row['LpPpStatus'],
                'AdCopyStatus' => $row['AdCopyStatus'],
                'ReviewsStatus' => $row['ReviewsStatus'],
                'ProductPrice' => $row['ProductPrice'],
            ];
        }
    }
}

header('Content-Type: application/json');
echo json_encode($products);

$conn->close();
?>