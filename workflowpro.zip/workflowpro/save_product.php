<?php
require_once('db.php');

// Get data from the POST request
$productId = $_POST['productId'];
$updatedProductName = mysqli_real_escape_string($conn, urldecode($_POST['productName']));
$updatedDoTest = mysqli_real_escape_string($conn, $_POST['doTest']);
$updatedStatusIvoryCoast = mysqli_real_escape_string($conn, $_POST['statusIvoryCoast']);
$updatedStatusSENEGAL = mysqli_real_escape_string($conn, $_POST['statusSenegal']);
$updatedStatusMALI = mysqli_real_escape_string($conn, $_POST['statusMali']);
$updatedStatusGUINEA = mysqli_real_escape_string($conn, $_POST['statusGuinea']);
$updatedStatusGAMBIA = mysqli_real_escape_string($conn, $_POST['statusGambia']);
$updatedStatusBURKINA = mysqli_real_escape_string($conn, $_POST['statusBurkina']);
$updatedStatusGABON = mysqli_real_escape_string($conn, $_POST['statusGabon']);
$updatedStatusCAMEROON = mysqli_real_escape_string($conn, $_POST['statusCameroon']);
$updatedStatusARGENTINA = mysqli_real_escape_string($conn, $_POST['statusArgentina']);
$updatedStatusRDC = mysqli_real_escape_string($conn, $_POST['statusRDC']);
$updatedSupplierName = mysqli_real_escape_string($conn, urldecode($_POST['supplierName']));
$updatedSourcingPrice = mysqli_real_escape_string($conn, $_POST['sourcingPrice']);
$updatedProductWeight = mysqli_real_escape_string($conn, $_POST['productWeight']);
$updatedNotes = mysqli_real_escape_string($conn, urldecode($_POST['notes']));
$updatedAdlibraryInspirationVideos = mysqli_real_escape_string($conn, urldecode($_POST['adlibraryInspirationVideos']));
$updatedCompetitorsLPPLinks = mysqli_real_escape_string($conn, urldecode($_POST['competitorsLPPLinks']));
$updatedAlibabaAliexpressLinks = mysqli_real_escape_string($conn, urldecode($_POST['alibabaAliexpressLinks']));
$updatedAlibabaAliexpressPrice = mysqli_real_escape_string($conn, urldecode($_POST['alibabaAliexpressPrice']));
$updatedMyLpPpLink = mysqli_real_escape_string($conn, urldecode($_POST['myLpPpLink']));
$updatedMyAdCopy = mysqli_real_escape_string($conn, urldecode($_POST['myAdCopy']));
$updatedMyVoiceOverScript = mysqli_real_escape_string($conn, urldecode($_POST['myVoiceOverScript']));
$selectedCountry = mysqli_real_escape_string($conn, $_POST['selectedCountry']);
$videosAds = mysqli_real_escape_string($conn, $_POST['videosAds']);
$voiceOver = mysqli_real_escape_string($conn, $_POST['voiceOver']);
$thumbnails = mysqli_real_escape_string($conn, $_POST['thumbnails']);
$lppp = mysqli_real_escape_string($conn, $_POST['lppp']);
$adcopy = mysqli_real_escape_string($conn, $_POST['adcopy']);
$reviews = mysqli_real_escape_string($conn, $_POST['reviews']);
$productPrice = mysqli_real_escape_string($conn, $_POST['productPrice']);


// Check if a new image file is uploaded
if (isset($_FILES['productImage']) && $_FILES['productImage']['error'] === UPLOAD_ERR_OK) {
    // Get the file extension
    $fileExtension = pathinfo($_FILES['productImage']['name'], PATHINFO_EXTENSION);

    // Generate a random number for the file name
    $randomNumber = mt_rand(100000000, 999999999);

    // Construct the new file name with the random number and original extension
    $newFileName = $randomNumber . '.' . $fileExtension;

    // Combine the new file name with the uploads directory
    $uploadedFilePath = 'img/' . $newFileName;

    // Move the uploaded file to the destination directory
    if (move_uploaded_file($_FILES['productImage']['tmp_name'], $uploadedFilePath)) {
        // File upload successful, save the file path in the database
        $imagePath = mysqli_real_escape_string($conn, $uploadedFilePath);
    } else {
        // File upload failed
        $response = array('success' => false, 'message' => 'Error moving uploaded file: ' . $_FILES['productImage']['error']);
        header('Content-Type: application/json');
        echo json_encode($response);
        exit; // Stop further execution
    }
} else {
    // No file was uploaded, keep the existing image path
    $existingImagePathQuery = "SELECT ProductImage FROM product WHERE ProductID = $productId";
    $existingImagePathResult = $conn->query($existingImagePathQuery);

    if ($existingImagePathResult->num_rows > 0) {
        $existingImagePathRow = $existingImagePathResult->fetch_assoc();
        $imagePath = $existingImagePathRow['ProductImage'];
    } else {
        $imagePath = 'img/default.jpg'; // Default image path if no image exists
    }
}

// Update the product in the database with the new image path
$sql = "UPDATE product SET ProductName = '$updatedProductName', DoTest = '$updatedDoTest', SupplierName = '$updatedSupplierName', SourcingPrice = '$updatedSourcingPrice', ProductWeight = '$updatedProductWeight', Notes = '$updatedNotes', AdlibraryInspirationVideos = '$updatedAdlibraryInspirationVideos', CompetitorsLinks = '$updatedCompetitorsLPPLinks', AlibabaAliexpressLinks = '$updatedAlibabaAliexpressLinks', AlibabaAliexpressPrice = '$updatedAlibabaAliexpressPrice', MyLpPpLink = '$updatedMyLpPpLink', MyAdCopy = '$updatedMyAdCopy', MyVoiceOverScript = '$updatedMyVoiceOverScript', ProductImage = '$imagePath' WHERE ProductID = $productId";

if ($conn->query($sql) === TRUE) {
    // If the update is successful, update the status for all countries
    $countries = array(
        'Ivory Coast' => $updatedStatusIvoryCoast,
        'Senegal' => $updatedStatusSENEGAL,
        'Mali' => $updatedStatusMALI,
        'Guinea Conakry' => $updatedStatusGUINEA,
        'Gambia' => $updatedStatusGAMBIA,
        'Burkina Faso' => $updatedStatusBURKINA,
        'Cameroon' => $updatedStatusCAMEROON,
        'Gabon' => $updatedStatusGABON,
        'Argentina' => $updatedStatusARGENTINA,
        'RDC' => $updatedStatusRDC
    );

    $updateStatusSuccess = true;

    foreach ($countries as $country => $status) {
        $sqlUpdateStatus = "UPDATE countrystatus SET Status = '$status' WHERE ProductID = $productId AND Country = '$country'";

        if ($conn->query($sqlUpdateStatus) !== TRUE) {
            // If there's an error in updating the status for any country, set updateStatusSuccess to false
            $updateStatusSuccess = false;
            break;
        }
    }

    // Update product status
    $sqlUpdateProductStatus = "UPDATE countrystatus SET VideosAdsStatus = '$videosAds', VoiceOverStatus = '$voiceOver', ThumbnailsStatus = '$thumbnails', LpPpStatus = '$lppp', AdCopyStatus = '$adcopy', ReviewsStatus = '$reviews', ProductPrice = '$productPrice' WHERE ProductID = $productId AND Country = '$selectedCountry'";

    if ($conn->query($sqlUpdateProductStatus) === TRUE) {
        // If the product status update is successful, return a success message
        $response = array('success' => true, 'message' => 'Product, status updated successfully');
        echo json_encode($response);
    } else {
        // If there's an error in updating the Video Ads status, return an error message
        $response = array('success' => false, 'message' => 'Error updating status: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    // If there's an error in updating the product, return an error message
    $response = array('success' => false, 'message' => 'Error updating product: ' . $conn->error);
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>